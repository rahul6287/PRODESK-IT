import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import DashboardOverview from './components/DashboardOverview';
import StudentManager from './components/StudentManager';
import StaffManager from './components/StaffManager';
import FinanceManager from './components/FinanceManager';
import AcademicsManager from './components/AcademicsManager';
import CommunicationCenter from './components/CommunicationCenter';
import StudentHub from './components/StudentHub';
import TeacherPortal from './components/TeacherPortal';
import LoginScreen from './components/LoginScreen';

import { 
  Branch, 
  Student, 
  Staff, 
  FeeTransaction, 
  TimetableItem, 
  Notice, 
  UserRole, 
  BranchId 
} from './types';

import { 
  INITIAL_BRANCHES, 
  INITIAL_STUDENTS, 
  INITIAL_STAFF, 
  INITIAL_TRANSACTIONS, 
  INITIAL_TIMETABLE, 
  INITIAL_NOTICES 
} from './initialData';

import { Info, Sparkles, LogIn, ExternalLink } from 'lucide-react';

export default function App() {
  // Auth states: check if an active user session is present in localStorage
  const [currentUser, setCurrentUser] = useState<any>(() => {
    const saved = localStorage.getItem('pjrs_erp_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Navigation & Role states
  const [currentRole, setCurrentRole] = useState<UserRole>(() => {
    const savedRole = localStorage.getItem('pjrs_erp_role');
    return (savedRole as UserRole) || 'super_admin';
  });

  const [selectedBranchId, setSelectedBranchId] = useState<BranchId>('all');
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Core Data States (Lazy loaded from localStorage)
  const [branches, setBranches] = useState<Branch[]>(INITIAL_BRANCHES);
  
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('pjrs_erp_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [staffList, setStaffList] = useState<Staff[]>(() => {
    const saved = localStorage.getItem('pjrs_erp_staff');
    return saved ? JSON.parse(saved) : INITIAL_STAFF;
  });

  const [transactions, setTransactions] = useState<FeeTransaction[]>(() => {
    const saved = localStorage.getItem('pjrs_erp_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [timetable, setTimetable] = useState<TimetableItem[]>(() => {
    const saved = localStorage.getItem('pjrs_erp_timetable');
    return saved ? JSON.parse(saved) : INITIAL_TIMETABLE;
  });

  const [notices, setNotices] = useState<Notice[]>(() => {
    const saved = localStorage.getItem('pjrs_erp_notices');
    return saved ? JSON.parse(saved) : INITIAL_NOTICES;
  });

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('pjrs_erp_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('pjrs_erp_staff', JSON.stringify(staffList));
  }, [staffList]);

  useEffect(() => {
    localStorage.setItem('pjrs_erp_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('pjrs_erp_timetable', JSON.stringify(timetable));
  }, [timetable]);

  useEffect(() => {
    localStorage.setItem('pjrs_erp_notices', JSON.stringify(notices));
  }, [notices]);

  // Adjust branch lock based on active role
  useEffect(() => {
    if (currentRole === 'branch_admin' && currentUser?.branchId) {
      setSelectedBranchId(currentUser.branchId);
    } else if (currentRole !== 'super_admin' && selectedBranchId === 'all') {
      setSelectedBranchId('central'); // default lock
    }
  }, [currentRole, currentUser, selectedBranchId]);

  // Adjust active tab based on active role
  useEffect(() => {
    if (currentRole === 'student') {
      setActiveTab('student_dashboard');
    } else if (currentRole === 'teacher') {
      setActiveTab('teacher_classroom');
    } else {
      setActiveTab('dashboard');
    }
  }, [currentRole]);

  // Handle operations
  const handleAddStudent = (newStudent: Student) => {
    setStudents(prev => [newStudent, ...prev]);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents(prev => prev.map(s => s.id === updatedStudent.id ? updatedStudent : s));
  };

  const handleAddStaff = (newStaff: Staff) => {
    setStaffList(prev => [newStaff, ...prev]);
  };

  const handleUpdateStaff = (updatedStaff: Staff) => {
    setStaffList(prev => prev.map(st => st.id === updatedStaff.id ? updatedStaff : st));
  };

  const handleDeleteStaff = (staffId: string) => {
    setStaffList(prev => prev.filter(st => st.id !== staffId));
  };

  const handlePurchaseStoreItem = (studentId: string, itemName: string, amount: number) => {
    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        // Increment feesTotal and feesPaid by amount
        const feesTotal = s.feesTotal + amount;
        const feesPaid = s.feesPaid + amount;
        const feesDue = Math.max(0, feesTotal - feesPaid);
        return { ...s, feesTotal, feesPaid, feesDue };
      }
      return s;
    }));
  };

  const handleAddTransaction = (newTx: FeeTransaction) => {
    setTransactions(prev => [newTx, ...prev]);
  };

  const handleUpdateStudentFees = (studentId: string, amountPaid: number) => {
    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        const feesPaid = s.feesPaid + amountPaid;
        const feesDue = Math.max(0, s.feesTotal - feesPaid);
        return { ...s, feesPaid, feesDue };
      }
      return s;
    }));
  };

  const handleUpdateStudentGrades = (studentId: string, grades: Record<string, number>) => {
    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        return { ...s, grades: { ...s.grades, ...grades } };
      }
      return s;
    }));
  };

  const handleAddTimetableItem = (newItem: TimetableItem) => {
    setTimetable(prev => [...prev, newItem]);
  };

  const handleAddNotice = (newNotice: Notice) => {
    setNotices(prev => [newNotice, ...prev]);
  };

  // Render correct tab view
  const renderTabView = () => {
    switch (activeTab) {
      case 'student_dashboard':
      case 'student_grades':
      case 'student_fees':
      case 'student_assignments':
      case 'student_chat':
        return (
          <StudentHub
            students={students}
            branches={branches}
            transactions={transactions}
            staffList={staffList}
            onAddTransaction={handleAddTransaction}
            onUpdateStudentFees={handleUpdateStudentFees}
            onPurchaseStoreItem={handlePurchaseStoreItem}
            activeStudentTab={activeTab.replace('student_', '')}
            setActiveStudentTab={(subTab) => setActiveTab(`student_${subTab}`)}
            loggedInStudentId={currentRole === 'student' ? currentUser?.id : undefined}
          />
        );
      case 'teacher_classroom':
      case 'teacher_gradebook':
      case 'teacher_assignments':
      case 'teacher_chat':
        return (
          <TeacherPortal
            students={students}
            branches={branches}
            staffList={staffList}
            onUpdateStudentGrades={handleUpdateStudentGrades}
            activeTeacherTab={activeTab.replace('teacher_', '')}
            setActiveTeacherTab={(subTab) => setActiveTab(`teacher_${subTab}`)}
            loggedInTeacherId={currentRole === 'teacher' ? currentUser?.id : undefined}
          />
        );
      case 'dashboard':
        return (
          <DashboardOverview
            branches={branches}
            students={students}
            staff={staffList}
            transactions={transactions}
            notices={notices}
            selectedBranchId={selectedBranchId}
            setActiveTab={setActiveTab}
          />
        );
      case 'students':
        return (
          <StudentManager
            students={students}
            branches={branches}
            selectedBranchId={selectedBranchId}
            onAddStudent={handleAddStudent}
            onUpdateStudent={handleUpdateStudent}
          />
        );
      case 'staff':
        return (
          <StaffManager
            staffList={staffList}
            branches={branches}
            selectedBranchId={selectedBranchId}
            onAddStaff={handleAddStaff}
            onUpdateStaff={handleUpdateStaff}
            onDeleteStaff={handleDeleteStaff}
          />
        );
      case 'finance':
        return (
          <FinanceManager
            students={students}
            transactions={transactions}
            branches={branches}
            selectedBranchId={selectedBranchId}
            onAddTransaction={handleAddTransaction}
            onUpdateStudentFees={handleUpdateStudentFees}
          />
        );
      case 'academics':
        return (
          <AcademicsManager
            students={students}
            timetable={timetable}
            branches={branches}
            selectedBranchId={selectedBranchId}
            onUpdateStudentGrades={handleUpdateStudentGrades}
            onAddTimetableItem={handleAddTimetableItem}
          />
        );
      case 'communication':
        return (
          <CommunicationCenter
            notices={notices}
            branches={branches}
            selectedBranchId={selectedBranchId}
            onAddNotice={handleAddNotice}
          />
        );
      default:
        return (
          <div className="p-8 text-center text-slate-500">
            Feature coming soon.
          </div>
        );
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('pjrs_erp_user');
    localStorage.removeItem('pjrs_erp_role');
    setCurrentUser(null);
    setCurrentRole('super_admin');
    setActiveTab('dashboard');
  };

  if (!currentUser) {
    return (
      <LoginScreen
        students={students}
        staffList={staffList}
        branches={branches}
        onAddStudent={handleAddStudent}
        onAddStaff={handleAddStaff}
        onLoginSuccess={(role, userPayload) => {
          setCurrentUser(userPayload);
          setCurrentRole(role);
          localStorage.setItem('pjrs_erp_user', JSON.stringify(userPayload));
          localStorage.setItem('pjrs_erp_role', role);

          // Redirect to appropriate tabs
          if (role === 'student') {
            setSelectedBranchId(userPayload.branchId);
            setActiveTab('student_dashboard');
          } else if (role === 'teacher') {
            setSelectedBranchId(userPayload.branchId);
            setActiveTab('teacher_classroom');
          } else if (role === 'branch_admin') {
            setSelectedBranchId(userPayload.branchId || 'central');
            setActiveTab('dashboard');
          } else {
            setSelectedBranchId('all');
            setActiveTab('dashboard');
          }
        }}
      />
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        branches={branches}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        selectedBranchId={selectedBranchId}
        setSelectedBranchId={setSelectedBranchId}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Main Workspace Frame */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50 overflow-y-auto">
        
        {/* Helper Notification Banner (Explains ERP capabilities or domain lock) */}
        <div className="bg-blue-600 px-6 py-2.5 text-white text-xs font-semibold flex items-center justify-between shadow-sm shrink-0">
          <div className="flex items-center gap-2">
            <Sparkles size={14} className="text-amber-300 animate-bounce" />
            <span>
              <strong>PJRS Group</strong> ERP Multi-Campus Active Ledger
            </span>
            <span className="bg-blue-700/60 text-blue-100 text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border border-blue-500/30">
              Domain Active: pjrs.porg (pjrs.org)
            </span>
          </div>
          <div className="flex items-center gap-4 text-[10px] font-mono">
            <span className="text-blue-100">Scope Lock: <strong>{currentRole.toUpperCase()}</strong></span>
            <a 
              href="https://pjrs.org" 
              target="_blank" 
              rel="noreferrer"
              className="hover:underline flex items-center gap-1 text-white"
            >
              Live School Site <ExternalLink size={10} />
            </a>
          </div>
        </div>

        {/* Dynamic Context Bar indicating restricted/active branch */}
        <div className="bg-slate-900 text-slate-300 px-8 py-3.5 flex flex-col sm:flex-row justify-between sm:items-center border-b border-slate-800 shrink-0 gap-2">
          <div className="flex items-center gap-2.5">
            <Info size={15} className="text-blue-400" />
            <span className="text-xs">
              {currentRole === 'super_admin' ? (
                <span>
                  HQ Group Admin Portal: You are viewing consolidated records across all <strong>4 branches</strong> (Delhi, Gurugram, Noida, Ghaziabad).
                </span>
              ) : currentRole === 'branch_admin' ? (
                <span>
                  Branch Admin Portal: Restricted administrative scope to <strong>{branches.find(b => b.id === selectedBranchId)?.name}</strong> campus records.
                </span>
              ) : currentRole === 'teacher' ? (
                <span>
                  Faculty Session (Mrs. Suman Sharma): Write permissions enabled for marking weekly attendance and uploading grades.
                </span>
              ) : (
                <span>
                  Student Portal: Welcome, Aarav Sharma. You are viewing Class 10 academic reports and dues ledger.
                </span>
              )}
            </span>
          </div>

          {/* Quick Stats shortcut */}
          <div className="flex gap-4 text-[10px] font-mono font-semibold text-slate-400">
            <span>Enrolled: <strong className="text-white">{students.length}</strong></span>
            <span>Faculty: <strong className="text-white">{staffList.length}</strong></span>
            <span>Deposited: <strong className="text-emerald-400">₹{transactions.reduce((sum, t) => sum + t.amount, 0).toLocaleString('en-IN')}</strong></span>
          </div>
        </div>

        {/* Active Content Module */}
        <div className="flex-1">
          {renderTabView()}
        </div>

      </main>
    </div>
  );
}
