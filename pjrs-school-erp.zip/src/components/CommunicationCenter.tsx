import React, { useState } from 'react';
import { 
  Bell, 
  Plus, 
  Send, 
  X, 
  Smartphone, 
  Mail, 
  CheckCircle,
  Building,
  AlertTriangle
} from 'lucide-react';
import { Notice, Branch, BranchId } from '../types';

interface CommunicationCenterProps {
  notices: Notice[];
  branches: Branch[];
  selectedBranchId: BranchId;
  onAddNotice: (newNotice: Notice) => void;
}

export default function CommunicationCenter({
  notices,
  branches,
  selectedBranchId,
  onAddNotice
}: CommunicationCenterProps) {
  const [isPublishOpen, setIsPublishOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Circular form states
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [targetScope, setTargetScope] = useState<BranchId>(selectedBranchId === 'all' ? 'all' : selectedBranchId);
  const [targetRecipient, setTargetRecipient] = useState<'All' | 'Parents' | 'Teachers' | 'Students'>('All');
  const [noticePriority, setNoticePriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [noticeSender, setNoticeSender] = useState('HQ Administration');

  // Broadcast Log Simulator
  const [isSmsSending, setIsSmsSending] = useState(false);
  const [smsResult, setSmsResult] = useState<string | null>(null);
  const [smsPhoneInput, setSmsPhoneInput] = useState('');
  const [smsMessage, setSmsMessage] = useState('');

  // Filter Notices
  const filteredNotices = notices.filter(n => {
    const matchesBranch = selectedBranchId === 'all' ? true : (n.branchId === 'all' || n.branchId === selectedBranchId);
    const matchesSearch = n.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          n.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesBranch && matchesSearch;
  });

  const handlePublishNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newContent) {
      alert('Please fill out notice title and description.');
      return;
    }

    const item: Notice = {
      id: `not_${Date.now()}`,
      title: newTitle,
      content: newContent,
      branchId: targetScope,
      date: new Date().toISOString().split('T')[0],
      sender: noticeSender,
      target: targetRecipient,
      priority: noticePriority
    };

    onAddNotice(item);
    setIsPublishOpen(false);

    // Reset Form
    setNewTitle('');
    setNewContent('');
    setNoticeSender('HQ Administration');
  };

  const handleSmsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!smsPhoneInput || !smsMessage) {
      alert('Please provide mobile number and SMS text.');
      return;
    }

    setIsSmsSending(true);
    setSmsResult(null);

    // Simulate Network/Telecom delay
    setTimeout(() => {
      setIsSmsSending(false);
      setSmsResult(`✅ API Success: Text notification securely routed to ${smsPhoneInput} via PJRS SMS gateway.`);
      setTimeout(() => {
        setSmsResult(null);
        setSmsPhoneInput('');
        setSmsMessage('');
      }, 5000);
    }, 1200);
  };

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans text-slate-900">School Communication Hub</h2>
          <p className="text-xs text-slate-500 mt-1">
            Dispatch digital circulars, publish important circulars, and trigger instant SMS alerts to parents/staff.
          </p>
        </div>
        <button
          onClick={() => setIsPublishOpen(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-blue-500/10 transition-all duration-150 self-start md:self-auto"
        >
          <Plus size={16} />
          Create Circular Notice
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Notice Board List (Left 2 columns) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden p-5 space-y-4">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">Active Campus Bulletins ({filteredNotices.length})</h3>
              <input
                type="text"
                placeholder="Search bulletin boards..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-slate-800 rounded-lg py-1 pl-3 pr-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="space-y-4">
              {filteredNotices.map((notice) => (
                <div key={notice.id} className="p-5 rounded-xl border border-slate-100 bg-slate-50/20 hover:bg-slate-50/50 transition-all space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                        notice.priority === 'High' 
                          ? 'bg-rose-50 text-rose-600 border-rose-100 font-bold'
                          : notice.priority === 'Medium'
                          ? 'bg-amber-50 text-amber-600 border-amber-100 font-semibold'
                          : 'bg-blue-50 text-blue-600 border-blue-100'
                      }`}>
                        {notice.priority} Priority
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                        Target: {notice.target}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">{notice.date}</span>
                  </div>

                  <h4 className="text-xs font-black text-slate-900">{notice.title}</h4>
                  <p className="text-[11px] text-slate-600 leading-relaxed">{notice.content}</p>

                  <div className="pt-3 border-t border-slate-100/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span className="flex items-center gap-1">
                      <Building size={11} /> Scope: 
                      <strong className="text-slate-600 uppercase">
                        {notice.branchId === 'all' ? 'All Campuses' : branches.find(b => b.id === notice.branchId)?.name.split(' (')[0] || 'Central'}
                      </strong>
                    </span>
                    <span>Dispatcher: <strong className="text-slate-600">{notice.sender}</strong></span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* SMS Broadcast simulation panel */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div className="space-y-5">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Smartphone className="text-blue-500" size={18} />
                <span>SMS Gateway Simulator</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-1">
                Trigger transactional SMS notices to Parents and Staff mobiles in India instantly.
              </p>
            </div>

            <form onSubmit={handleSmsSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Parent Mobile Number *</label>
                <input
                  type="text"
                  required
                  placeholder="+91 98765 43210"
                  value={smsPhoneInput}
                  onChange={(e) => setSmsPhoneInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">SMS Broadcast Message *</label>
                <textarea
                  required
                  rows={4}
                  maxLength={160}
                  placeholder="Dear Parent, your ward Aarav was marked ABSENT for Class 10 morning session. Please call Principal office at +911145982211. - PJRS"
                  value={smsMessage}
                  onChange={(e) => setSmsMessage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500"
                />
                <span className="text-[9px] text-slate-400 font-mono float-right">
                  {smsMessage.length}/160 Characters (1 SMS credit)
                </span>
              </div>

              <button
                type="submit"
                disabled={isSmsSending}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-xs font-semibold shadow transition-all duration-150 flex items-center justify-center gap-1.5"
              >
                {isSmsSending ? (
                  <>
                    <span className="h-3 w-3 border-2 border-white/25 border-t-white rounded-full animate-spin" />
                    Connecting to Telecom Route...
                  </>
                ) : (
                  <>
                    <Send size={13} />
                    Send Transactional SMS
                  </>
                )}
              </button>
            </form>

            {smsResult && (
              <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-100 rounded-lg text-[10px] font-mono leading-relaxed flex gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span>{smsResult}</span>
              </div>
            )}
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 flex gap-2.5 text-[10px] text-slate-500 mt-6 leading-relaxed">
            <AlertTriangle size={16} className="text-amber-500 shrink-0" />
            <span>
              All SMS broadcasts conform to TRAI DLT registration templates. Outbound texts must mention <strong>PJRS</strong>.
            </span>
          </div>
        </div>
      </div>

      {/* Publish circular Notice Modal */}
      {isPublishOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="bg-slate-900 text-white p-6">
              <h2 className="text-sm font-bold font-sans">Dispatch Digital Notice</h2>
              <p className="text-[10px] text-slate-400 font-mono mt-1">Publish to the central and campus boards immediately.</p>
            </div>

            <form onSubmit={handlePublishNotice} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Circular Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Independence Day Dress Code"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Circular Details / Content *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Provide precise details of the instructions for stakeholders..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Campus Scope</label>
                  <select
                    value={targetScope}
                    onChange={(e) => setTargetScope(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="all">🌐 All Campuses</option>
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>📍 {b.name.split(' (')[0]}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Target Audience</label>
                  <select
                    value={targetRecipient}
                    onChange={(e) => setTargetRecipient(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="All">All Audiences</option>
                    <option value="Parents">Parents Only</option>
                    <option value="Teachers">Teachers Only</option>
                    <option value="Students">Students Only</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Priority Indicator</label>
                  <select
                    value={noticePriority}
                    onChange={(e) => setNoticePriority(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="High">🚨 High Priority</option>
                    <option value="Medium">⚡ Medium Priority</option>
                    <option value="Low">💤 Low Priority</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Signatory / Sender</label>
                  <input
                    type="text"
                    required
                    value={noticeSender}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setIsPublishOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3.5 py-2 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-lg text-xs font-semibold shadow"
                >
                  Broadcast Circular
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
