import React, { useState } from 'react';
import { 
  BookOpen, 
  Calendar, 
  Award, 
  Edit3, 
  CheckCircle,
  FileText,
  User,
  Plus
} from 'lucide-react';
import { Student, TimetableItem, Branch, BranchId } from '../types';

interface AcademicsManagerProps {
  students: Student[];
  timetable: TimetableItem[];
  branches: Branch[];
  selectedBranchId: BranchId;
  onUpdateStudentGrades: (studentId: string, grades: Record<string, number>) => void;
  onAddTimetableItem: (newItem: TimetableItem) => void;
}

export default function AcademicsManager({
  students,
  timetable,
  branches,
  selectedBranchId,
  onUpdateStudentGrades,
  onAddTimetableItem
}: AcademicsManagerProps) {
  const [activeTab, setActiveTab] = useState<'timetable' | 'grades'>('timetable');
  const [selectedClass, setSelectedClass] = useState('Class 10');
  const [selectedSection, setSelectedSection] = useState('A');

  // Grades entry state
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [editMath, setEditMath] = useState('');
  const [editScience, setEditScience] = useState('');
  const [editEnglish, setEditEnglish] = useState('');
  const [editHistory, setEditHistory] = useState('');
  const [editHindi, setEditHindi] = useState('');

  // Timetable scheduling state
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [newDay, setNewDay] = useState<'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday'>('Monday');
  const [newSubject, setNewSubject] = useState('Mathematics');
  const [newTeacher, setNewTeacher] = useState('');
  const [newStart, setNewStart] = useState('08:30');
  const [newEnd, setNewEnd] = useState('09:20');
  const [newRoom, setNewRoom] = useState('Room 201');

  // Filter timetable
  const filteredTimetable = timetable.filter(item => {
    const matchesBranch = selectedBranchId === 'all' ? true : item.branchId === selectedBranchId;
    const matchesClass = item.className === selectedClass && item.section === selectedSection;
    return matchesBranch && matchesClass;
  });

  // Filter students for grades entry
  const filteredStudents = students.filter(s => {
    const matchesBranch = selectedBranchId === 'all' ? true : s.branchId === selectedBranchId;
    const matchesClass = s.class === selectedClass && s.section === selectedSection;
    return matchesBranch && matchesClass;
  });

  const handleEditGradesClick = (student: Student) => {
    setEditingStudentId(student.id);
    setEditMath(String(student.grades.Mathematics || 0));
    setEditScience(String(student.grades.Science || 0));
    setEditEnglish(String(student.grades.English || 0));
    setEditHistory(String(student.grades.History || 0));
    setEditHindi(String(student.grades.Hindi || 0));
  };

  const handleSaveGrades = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudentId) return;

    const gradesObj = {
      Mathematics: Math.min(100, Math.max(0, Number(editMath) || 0)),
      Science: Math.min(100, Math.max(0, Number(editScience) || 0)),
      English: Math.min(100, Math.max(0, Number(editEnglish) || 0)),
      History: Math.min(100, Math.max(0, Number(editHistory) || 0)),
      Hindi: Math.min(100, Math.max(0, Number(editHindi) || 0))
    };

    onUpdateStudentGrades(editingStudentId, gradesObj);
    setEditingStudentId(null);
  };

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeacher || !newSubject) {
      alert('Please enter a subject and a teacher.');
      return;
    }

    const item: TimetableItem = {
      id: `tt_${Date.now()}`,
      className: selectedClass,
      section: selectedSection,
      branchId: selectedBranchId === 'all' ? 'central' : selectedBranchId,
      day: newDay,
      subject: newSubject,
      teacherName: newTeacher,
      startTime: newStart,
      endTime: newEnd,
      roomNo: newRoom
    };

    onAddTimetableItem(item);
    setIsScheduleOpen(false);
    setNewTeacher('');
  };

  const daysOfWeek: ('Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday')[] = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
  ];

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Sub Header / Tab Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h2 className="text-xl font-bold font-sans text-slate-900">Academic & Exam Assessment</h2>
          <p className="text-xs text-slate-500 mt-1">
            Build weekly class timetables and upload student mid-term/annual mark sheets in real-time.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-slate-100 p-1 rounded-xl self-start md:self-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('timetable')}
            className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'timetable'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Calendar size={14} />
            Class Timetable
          </button>
          <button
            onClick={() => setActiveTab('grades')}
            className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              activeTab === 'grades'
                ? 'bg-white text-slate-950 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Award size={14} />
            Exam Gradebook
          </button>
        </div>
      </div>

      {/* Class/Section Selector Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 border border-slate-100 p-4 rounded-xl">
        <div>
          <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">Select Class</label>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none mt-1"
          >
            <option value="Class 9">Class 9</option>
            <option value="Class 10">Class 10</option>
            <option value="Class 11">Class 11</option>
            <option value="Class 12">Class 12</option>
          </select>
        </div>

        <div>
          <label className="text-[10px] font-bold text-slate-400 font-mono uppercase">Select Section</label>
          <select
            value={selectedSection}
            onChange={(e) => setSelectedSection(e.target.value)}
            className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none mt-1"
          >
            <option value="A">Section A</option>
            <option value="B">Section B</option>
            <option value="C">Section C</option>
          </select>
        </div>

        <div className="flex items-end justify-end">
          {activeTab === 'timetable' && (
            <button
              onClick={() => setIsScheduleOpen(true)}
              className="w-full md:w-auto flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg text-xs shadow transition-colors"
            >
              <Plus size={14} />
              Schedule Class
            </button>
          )}
        </div>
      </div>

      {/* Tab Contents */}
      {activeTab === 'timetable' ? (
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Weekly Schedule for {selectedClass} - {selectedSection}</h3>
            <p className="text-[11px] text-slate-500">Scheduled classroom learning sequences.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-slate-50/50">
            {daysOfWeek.map((day) => {
              const dayLessons = filteredTimetable.filter(t => t.day === day);
              return (
                <div key={day} className="bg-white border border-slate-100 rounded-xl p-4 shadow-xs space-y-3">
                  <div className="flex justify-between items-center border-b border-slate-50 pb-2">
                    <span className="text-xs font-bold text-slate-900 uppercase font-mono tracking-wider">{day}</span>
                    <span className="text-[10px] text-slate-400 font-mono">({dayLessons.length} periods)</span>
                  </div>

                  <div className="space-y-2">
                    {dayLessons.length > 0 ? (
                      dayLessons.map((lesson) => (
                        <div key={lesson.id} className="p-2.5 rounded-lg border border-slate-50 bg-slate-50/40 text-[11px]">
                          <div className="flex justify-between font-bold text-slate-800">
                            <span>{lesson.subject}</span>
                            <span className="font-mono text-[10px] text-blue-600">{lesson.startTime} - {lesson.endTime}</span>
                          </div>
                          <div className="flex justify-between text-slate-500 mt-1">
                            <span>👨‍🏫 {lesson.teacherName}</span>
                            <span className="font-mono bg-slate-100 px-1 py-0.2 rounded">{lesson.roomNo}</span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-[11px] text-slate-400 italic py-4 text-center">No classes scheduled for this day.</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* GRADES GRADEBOOK */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">Grades Ledger for {selectedClass} - {selectedSection}</h3>
              <p className="text-[11px] text-slate-500">Record, review, and lock terminal examinations scores.</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-100">
                    <th className="p-4 font-semibold">Student Name / Roll</th>
                    <th className="p-4 font-semibold text-center">Mathematics</th>
                    <th className="p-4 font-semibold text-center">Science</th>
                    <th className="p-4 font-semibold text-center">English</th>
                    <th className="p-4 font-semibold text-center">History</th>
                    <th className="p-4 font-semibold text-center">Hindi</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredStudents.length > 0 ? (
                    filteredStudents.map((student) => {
                      // calculate average score
                      const gradesList = Object.values(student.grades);
                      const avg = gradesList.length > 0 ? Math.round(gradesList.reduce((sum, g) => sum + g, 0) / gradesList.length) : 0;
                      return (
                        <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="p-4">
                            <div className="font-bold text-slate-950">{student.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{student.rollNumber}</div>
                          </td>
                          <td className="p-4 text-center font-mono font-bold text-slate-700">{student.grades.Mathematics || 0}</td>
                          <td className="p-4 text-center font-mono font-bold text-slate-700">{student.grades.Science || 0}</td>
                          <td className="p-4 text-center font-mono font-bold text-slate-700">{student.grades.English || 0}</td>
                          <td className="p-4 text-center font-mono font-bold text-slate-700">{student.grades.History || 0}</td>
                          <td className="p-4 text-center font-mono font-bold text-slate-700">{student.grades.Hindi || 0}</td>
                          <td className="p-4 text-right">
                            <button
                              onClick={() => handleEditGradesClick(student)}
                              className="bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 font-semibold px-2.5 py-1.5 rounded-lg text-[10px] transition-colors"
                            >
                              Edit Grades
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400">
                        No students enrolled in this Class/Section.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Edit Grades Card sidebar */}
          <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
            {editingStudentId ? (
              <form onSubmit={handleSaveGrades} className="space-y-5">
                <div className="border-b border-slate-100 pb-3">
                  <h4 className="text-sm font-bold text-slate-900">Upload Exam Grades</h4>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">
                    Student: {students.find(s => s.id === editingStudentId)?.name}
                  </p>
                </div>

                <div className="space-y-4 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Mathematics (Max 100)</label>
                    <input
                      type="number"
                      required
                      value={editMath}
                      onChange={(e) => setEditMath(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Science (Max 100)</label>
                    <input
                      type="number"
                      required
                      value={editScience}
                      onChange={(e) => setEditScience(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">English (Max 100)</label>
                    <input
                      type="number"
                      required
                      value={editEnglish}
                      onChange={(e) => setEditEnglish(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">History (Max 100)</label>
                    <input
                      type="number"
                      required
                      value={editHistory}
                      onChange={(e) => setEditHistory(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Hindi (Max 100)</label>
                    <input
                      type="number"
                      required
                      value={editHindi}
                      onChange={(e) => setEditHindi(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="flex gap-2.5 pt-4">
                  <button
                    type="button"
                    onClick={() => setEditingStudentId(null)}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 py-2 rounded-lg text-xs font-semibold transition-colors text-center"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-xs font-semibold shadow transition-colors text-center"
                  >
                    Lock Grades
                  </button>
                </div>
              </form>
            ) : (
              <div className="text-center py-24 text-slate-400 space-y-3">
                <Award className="mx-auto text-slate-300" size={40} />
                <p className="text-xs">Click "Edit Grades" on any student to update or adjust their terminal examinations mark sheet.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Schedule Timetable Item Modal */}
      {isScheduleOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="bg-slate-900 text-white p-6">
              <h2 className="text-sm font-bold font-sans">Schedule New Period / Class</h2>
              <p className="text-[10px] text-slate-400 font-mono mt-1">Class {selectedClass} ({selectedSection})</p>
            </div>

            <form onSubmit={handleScheduleSubmit} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Day of Week</label>
                <select
                  value={newDay}
                  onChange={(e) => setNewDay(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                >
                  <option value="Monday">Monday</option>
                  <option value="Tuesday">Tuesday</option>
                  <option value="Wednesday">Wednesday</option>
                  <option value="Thursday">Thursday</option>
                  <option value="Friday">Friday</option>
                  <option value="Saturday">Saturday</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Start Time</label>
                  <input
                    type="time"
                    required
                    value={newStart}
                    onChange={(e) => setNewStart(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs font-mono focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">End Time</label>
                  <input
                    type="time"
                    required
                    value={newEnd}
                    onChange={(e) => setNewEnd(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs font-mono focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Subject / Topic</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Science Lab"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Assigned Faculty / Teacher</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mrs. Suman Sharma"
                  value={newTeacher}
                  onChange={(e) => setNewTeacher(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Classroom / Room Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lab B, Room 201"
                  value={newRoom}
                  onChange={(e) => setNewRoom(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setIsScheduleOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3.5 py-2 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-lg text-xs font-semibold shadow"
                >
                  Verify & Add Block
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
