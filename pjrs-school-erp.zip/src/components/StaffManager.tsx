import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  User, 
  Phone, 
  Mail, 
  Briefcase, 
  Calendar, 
  CheckCircle, 
  AlertCircle,
  X,
  BookOpen,
  Trash2
} from 'lucide-react';
import { Staff, Branch, BranchId } from '../types';

interface StaffManagerProps {
  staffList: Staff[];
  branches: Branch[];
  selectedBranchId: BranchId;
  onAddStaff: (newStaff: Staff) => void;
  onUpdateStaff: (updatedStaff: Staff) => void;
  onDeleteStaff?: (id: string) => void;
}

export default function StaffManager({
  staffList,
  branches,
  selectedBranchId,
  onAddStaff,
  onUpdateStaff,
  onDeleteStaff
}: StaffManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'Teacher' | 'Principal' | 'Admin' | 'Finance' | 'Support'>('Teacher');
  const [newBranch, setNewBranch] = useState(selectedBranchId === 'all' ? 'central' : selectedBranchId);
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newSalary, setNewSalary] = useState('50000');
  const [newQualification, setNewQualification] = useState('');
  const [newSpecialty, setNewSpecialty] = useState('');
  const [newAssignedClass, setNewAssignedClass] = useState('');
  const [newPassword, setNewPassword] = useState('teacher123');

  // Filter staff based on branch and role
  const filteredStaff = staffList.filter(st => {
    const matchesBranch = selectedBranchId === 'all' ? true : st.branchId === selectedBranchId;
    const matchesRole = selectedRole === 'all' ? true : st.role === selectedRole;
    const matchesSearch = st.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          st.empId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (st.subjectSpecialty && st.subjectSpecialty.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesBranch && matchesRole && matchesSearch;
  });

  const handlePaySalary = (staffMember: Staff) => {
    const updated = { ...staffMember, salaryStatus: 'Paid' as const };
    onUpdateStaff(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail || !newPhone) {
      alert('Please fill out name, email, and phone.');
      return;
    }

    const empId = `PJRS-EMP-${Math.floor(100 + Math.random() * 900)}`;
    const id = `staff_${Date.now()}`;

    const newStaffObj: Staff = {
      id,
      empId,
      name: newName,
      role: newRole,
      branchId: newBranch,
      email: newEmail,
      password: newPassword || 'teacher123',
      phone: newPhone,
      salary: Number(newSalary) || 50000,
      salaryStatus: 'Pending',
      qualification: newQualification || 'B.Ed, Graduate',
      joiningDate: new Date().toISOString().split('T')[0],
      subjectSpecialty: newRole === 'Teacher' ? newSpecialty : undefined,
      assignedClass: newRole === 'Teacher' && newAssignedClass ? newAssignedClass : undefined
    };

    onAddStaff(newStaffObj);
    setIsAddModalOpen(false);

    // Reset Form
    setNewName('');
    setNewEmail('');
    setNewPhone('');
    setNewQualification('');
    setNewSpecialty('');
    setNewAssignedClass('');
    setNewPassword('teacher123');
  };

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans text-slate-900">Faculty & Staff Directory</h2>
          <p className="text-xs text-slate-500 mt-1">
            Manage teacher registries, specialized departments, and administrative salaries across campuses.
          </p>
        </div>
        <button
          onClick={() => {
            setNewBranch(selectedBranchId === 'all' ? 'central' : selectedBranchId);
            setIsAddModalOpen(true);
          }}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-blue-500/10 transition-all duration-150 self-start md:self-auto"
        >
          <Plus size={16} />
          Add Faculty / Staff
        </button>
      </div>

      {/* Search and Filters panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 border border-slate-100 p-4 rounded-xl">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-slate-400" size={16} />
          <input
            type="text"
            placeholder="Search name, Employee ID, subject..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg py-2 pl-9 pr-4 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
          >
            <option value="all">💼 Filter by Role: All Staff</option>
            <option value="Teacher">Teacher / Faculty</option>
            <option value="Principal">Principal / Campus Director</option>
            <option value="Admin">Administrator</option>
            <option value="Finance">Finance / Accountant</option>
            <option value="Support">Support Staff</option>
          </select>
        </div>

        <div className="text-xs text-slate-500 flex items-center justify-end font-mono">
          Showing {filteredStaff.length} of {staffList.length} Active Staff Members
        </div>
      </div>

      {/* Staff Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStaff.map((staff) => {
          const branch = branches.find(b => b.id === staff.branchId);
          return (
            <div key={staff.id} className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-150 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                {/* Name / ID / Branch Tag */}
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded border bg-blue-50 text-blue-600 border-blue-100">
                      {staff.role}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-2">{staff.name}</h3>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5">{staff.empId}</p>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                    📍 {branch?.code}
                  </span>
                </div>

                <div className="border-t border-slate-100 pt-3 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Specialty:</span>
                    <span className="font-semibold text-slate-800">{staff.subjectSpecialty || 'N/A (Non-Teaching)'}</span>
                  </div>
                  {staff.assignedClass && (
                    <div className="flex justify-between text-slate-600">
                      <span className="text-slate-400">Class Teacher of:</span>
                      <span className="font-semibold text-slate-800 flex items-center gap-1">
                        <BookOpen size={12} className="text-blue-500" /> {staff.assignedClass}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Qualifications:</span>
                    <span className="font-medium text-slate-800 text-right truncate max-w-[160px]" title={staff.qualification}>
                      {staff.qualification}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span className="text-slate-400">Monthly Salary:</span>
                    <span className="font-mono font-bold text-slate-900">₹{staff.salary.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* Contacts */}
                <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-[11px] text-slate-500 font-mono">
                  <div className="flex items-center gap-2">
                    <Mail size={12} />
                    <span className="truncate">{staff.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={12} />
                    <span>{staff.phone}</span>
                  </div>
                </div>
              </div>

              {/* Salary Release Action Panel */}
              <div className="border-t border-slate-100 pt-4 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  {staff.salaryStatus === 'Paid' ? (
                    <span className="text-emerald-600 bg-emerald-50 border border-emerald-100 px-2 py-1 rounded font-mono font-bold flex items-center gap-1">
                      <CheckCircle size={12} /> PAID
                    </span>
                  ) : (
                    <span className="text-amber-600 bg-amber-50 border border-amber-100 px-2 py-1 rounded font-mono font-bold flex items-center gap-1">
                      <AlertCircle size={12} /> PENDING
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {staff.salaryStatus === 'Pending' && (
                    <button
                      onClick={() => handlePaySalary(staff)}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-2.5 py-1.5 rounded-lg text-[10px] transition-colors"
                    >
                      Release Salary
                    </button>
                  )}
                  {onDeleteStaff && (
                    <button
                      onClick={() => {
                        if (window.confirm(`Are you sure you want to terminate the contract and delete staff member "${staff.name}"? This action is irreversible.`)) {
                          onDeleteStaff(staff.id);
                        }
                      }}
                      className="bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100 p-1.5 rounded-lg transition-colors flex items-center justify-center"
                      title="Terminate Contract"
                    >
                      <Trash2 size={13} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Staff Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-mono uppercase tracking-wider text-slate-400">HQ HR Registry</h3>
                <h2 className="text-base font-bold font-sans mt-0.5">Recruit New School Faculty / Staff</h2>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Enter full name"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Role *</label>
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="Teacher">Teacher / Faculty</option>
                    <option value="Principal">Principal / Campus Director</option>
                    <option value="Admin">Administrator</option>
                    <option value="Finance">Finance / Accountant</option>
                    <option value="Support">Support Staff</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Campus Branch *</label>
                  <select
                    value={newBranch}
                    onChange={(e) => setNewBranch(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Monthly Salary (INR)</label>
                  <input
                    type="number"
                    value={newSalary}
                    onChange={(e) => setNewSalary(e.target.value)}
                    placeholder="50000"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Qualifications *</label>
                  <input
                    type="text"
                    required
                    value={newQualification}
                    onChange={(e) => setNewQualification(e.target.value)}
                    placeholder="e.g. M.Sc. Mathematics, B.Ed."
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Contact Phone *</label>
                  <input
                    type="text"
                    required
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="+91 XXXXX XXXXX"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Staff Email *</label>
                  <input
                    type="email"
                    required
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="staff@pjrs.org"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Login Password *</label>
                  <input
                    type="text"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Default is teacher123"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {newRole === 'Teacher' && (
                <div className="border-t border-slate-100 pt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Subject Specialty</label>
                    <input
                      type="text"
                      value={newSpecialty}
                      onChange={(e) => setNewSpecialty(e.target.value)}
                      placeholder="e.g. Science, Mathematics"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Assigned Class Teacher Duty</label>
                    <input
                      type="text"
                      value={newAssignedClass}
                      onChange={(e) => setNewAssignedClass(e.target.value)}
                      placeholder="e.g. Class 10-A (Optional)"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-6 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-md shadow-blue-500/10 transition-colors"
                >
                  Recruit Staff Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
