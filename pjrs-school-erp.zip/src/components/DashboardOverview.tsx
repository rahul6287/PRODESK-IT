import React from 'react';
import { 
  TrendingUp, 
  Users, 
  BookOpen, 
  DollarSign, 
  Award,
  Bell,
  Calendar,
  Building,
  CheckCircle,
  AlertCircle,
  X,
  User
} from 'lucide-react';
import { Branch, Student, Staff, FeeTransaction, Notice, BranchId } from '../types';

interface DashboardOverviewProps {
  branches: Branch[];
  students: Student[];
  staff: Staff[];
  transactions: FeeTransaction[];
  notices: Notice[];
  selectedBranchId: BranchId;
  setActiveTab: (tab: string) => void;
}

export default function DashboardOverview({
  branches,
  students,
  staff,
  transactions,
  notices,
  selectedBranchId,
  setActiveTab
}: DashboardOverviewProps) {
  
  // HQ Multi-Campus Student Explorer States
  const [explorerBranchId, setExplorerBranchId] = React.useState<BranchId>('central');
  const [explorerSearchTerm, setExplorerSearchTerm] = React.useState<string>('');
  const [explorerGenderFilter, setExplorerGenderFilter] = React.useState<string>('All');
  const [selectedExplorerStudent, setSelectedExplorerStudent] = React.useState<Student | null>(null);

  // Filter students for the HQ multi-campus explorer
  const explorerFilteredStudents = students.filter(s => {
    const matchesBranch = s.branchId === explorerBranchId;
    const matchesSearch = s.name.toLowerCase().includes(explorerSearchTerm.toLowerCase()) || 
                          s.rollNumber.toLowerCase().includes(explorerSearchTerm.toLowerCase());
    const matchesGender = explorerGenderFilter === 'All' ? true : s.gender === explorerGenderFilter;
    return matchesBranch && matchesSearch && matchesGender;
  });

  // Filtering datasets based on active branch scope
  const filteredStudents = selectedBranchId === 'all' 
    ? students 
    : students.filter(s => s.branchId === selectedBranchId);

  const filteredStaff = selectedBranchId === 'all' 
    ? staff 
    : staff.filter(st => st.branchId === selectedBranchId);

  const filteredTransactions = selectedBranchId === 'all' 
    ? transactions 
    : transactions.filter(t => t.branchId === selectedBranchId);

  const activeBranch = branches.find(b => b.id === selectedBranchId);

  // Financial Calculations
  const totalFeesExpected = filteredStudents.reduce((sum, s) => sum + s.feesTotal, 0);
  const totalFeesPaid = filteredStudents.reduce((sum, s) => sum + s.feesPaid, 0);
  const totalFeesDue = filteredStudents.reduce((sum, s) => sum + s.feesDue, 0);
  const totalSalaryPayout = filteredStaff.reduce((sum, st) => sum + st.salary, 0);

  // General Stats
  const studentCount = filteredStudents.length;
  const staffCount = filteredStaff.length;
  const avgAttendance = filteredStudents.length > 0 
    ? (filteredStudents.reduce((sum, s) => sum + s.attendanceRate, 0) / studentCount).toFixed(1) 
    : '0';

  // Branch Specific Stats
  const branchMetrics = branches.map(b => {
    const bStudents = students.filter(s => s.branchId === b.id);
    const bStaff = staff.filter(st => st.branchId === b.id);
    const feesPaid = bStudents.reduce((sum, s) => sum + s.feesPaid, 0);
    const feesTotal = bStudents.reduce((sum, s) => sum + s.feesTotal, 0);
    const collectionPercentage = feesTotal > 0 ? Math.round((feesPaid / feesTotal) * 100) : 0;

    return {
      id: b.id,
      name: b.name,
      code: b.code,
      studentCount: bStudents.length,
      staffCount: bStaff.length,
      feesPaid,
      feesTotal,
      collectionPercentage,
      color: b.color
    };
  });

  // Calculate highest and lowest enrollment
  const sortedBranchesByEnrollment = [...branchMetrics].sort((a, b) => b.studentCount - a.studentCount);
  
  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 p-6 rounded-2xl border border-slate-800 shadow-xl text-white">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="bg-blue-500/20 text-blue-300 text-[10px] uppercase font-mono px-2 py-0.5 rounded border border-blue-500/30 font-semibold tracking-wider">
              Management Portal
            </span>
            <span className="text-slate-400 text-xs font-mono">• Established 2012</span>
          </div>
          <h2 className="text-2xl font-bold font-sans tracking-tight">
            {selectedBranchId === 'all' 
              ? 'PJRS Group of Schools - HQ Central Command' 
              : `PJRS ERP - ${activeBranch?.name}`}
          </h2>
          <p className="text-slate-300 text-xs mt-1 max-w-xl">
            {selectedBranchId === 'all' 
              ? 'Operational analytics, financial audits, student capacities, and multi-campus governance across all 4 school branches.'
              : `${activeBranch?.address} | Principal: ${activeBranch?.principal}`}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1 font-mono text-xs bg-slate-950/40 p-3 rounded-lg border border-slate-800/80 min-w-[200px]">
          <div className="flex justify-between w-full text-slate-400">
            <span>Server Time:</span>
            <span className="text-white">10:54 AM</span>
          </div>
          <div className="flex justify-between w-full text-slate-400">
            <span>Branch Code:</span>
            <span className="text-white">{selectedBranchId === 'all' ? 'PJRS-HQ-CONSOL' : activeBranch?.code}</span>
          </div>
          <div className="flex justify-between w-full text-slate-400">
            <span>System State:</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" /> Synchronized
            </span>
          </div>
        </div>
      </div>

      {/* Primary KPI Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Students */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all duration-200">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
              <Users size={22} />
            </div>
            <span className="text-xs font-mono font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Active
            </span>
          </div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-bold">Total Students</span>
          <h3 className="text-2xl font-bold font-sans text-slate-900 mt-1">{studentCount}</h3>
          <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
            <Building size={12} className="text-slate-400" />
            Across {selectedBranchId === 'all' ? '4 campus branches' : 'this campus'}
          </p>
        </div>

        {/* Staff Members */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all duration-200">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
              <BookOpen size={22} />
            </div>
            <span className="text-xs font-mono font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
              Faculty
            </span>
          </div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-bold">Teachers & Staff</span>
          <h3 className="text-2xl font-bold font-sans text-slate-900 mt-1">{staffCount}</h3>
          <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
            <CheckCircle size={12} className="text-emerald-500" />
            1:15 Teacher-to-Student Ratio
          </p>
        </div>

        {/* Fees Collected */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all duration-200">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
              <DollarSign size={22} />
            </div>
            <span className="text-xs font-mono font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              {totalFeesExpected > 0 ? Math.round((totalFeesPaid / totalFeesExpected) * 100) : 0}% Realized
            </span>
          </div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-bold">Fees Collected</span>
          <h3 className="text-2xl font-bold font-sans text-emerald-600 mt-1">₹{totalFeesPaid.toLocaleString('en-IN')}</h3>
          <p className="text-[11px] text-slate-500 mt-2 flex justify-between">
            <span>Expected: ₹{totalFeesExpected.toLocaleString('en-IN')}</span>
          </p>
        </div>

        {/* Average Attendance */}
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all duration-200">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
              <Award size={22} />
            </div>
            <span className="text-xs font-mono font-medium text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
              Target: 90%
            </span>
          </div>
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-bold">Avg. Attendance</span>
          <h3 className="text-2xl font-bold font-sans text-slate-900 mt-1">{avgAttendance}%</h3>
          <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
            <TrendingUp size={12} className={Number(avgAttendance) >= 88 ? 'text-emerald-500' : 'text-amber-500'} />
            Overall student daily attendance rate
          </p>
        </div>
      </div>

      {/* Main Stats Panel - SVG bar chart and analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Branch Comparisons (Highly detailed SVG chart for Multi-Branch modeling) */}
        <div className="lg:col-span-2 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="text-base font-bold text-slate-900">Multi-Branch Campus Strength Comparison</h4>
                <p className="text-xs text-slate-500">Student enrollment, faculty strength, and collected fees audit.</p>
              </div>
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold bg-slate-50 border border-slate-100 px-2.5 py-1 rounded">
                Consolidated Data
              </span>
            </div>

            {/* Simulated Custom HTML/SVG Chart */}
            <div className="space-y-6 my-6">
              {branchMetrics.map((bm) => {
                const maxStudents = 20; // scale factor
                const barWidthPercent = Math.min((bm.studentCount / maxStudents) * 100, 100);
                return (
                  <div key={bm.id} className="space-y-2">
                    <div className="flex justify-between items-center text-xs text-slate-700">
                      <div className="flex items-center gap-2">
                        <span className="h-3 w-3 rounded-full" style={{ backgroundColor: bm.color }} />
                        <span className="font-semibold text-slate-900">{bm.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">({bm.code})</span>
                      </div>
                      <div className="font-mono text-slate-600 flex gap-4">
                        <span>👥 <strong>{bm.studentCount}</strong> Students</span>
                        <span>🎓 <strong>{bm.staffCount}</strong> Staff</span>
                        <span className="text-emerald-600 font-semibold">💳 {bm.collectionPercentage}% Collected</span>
                      </div>
                    </div>
                    {/* Progress Bar Container */}
                    <div className="relative w-full h-3.5 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-500 ease-out"
                        style={{ 
                          width: `${barWidthPercent}%`, 
                          backgroundColor: bm.color 
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4 mt-2 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
            <div className="flex gap-4">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-blue-500" />
                <span>Central Campus (Delhi)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <span>South Campus (Gurugram)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-violet-500" />
                <span>East Campus (Noida)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-500" />
                <span>West Campus (Ghaziabad)</span>
              </div>
            </div>
            <div className="font-mono text-[10px] text-blue-600 font-semibold uppercase hover:underline cursor-pointer" onClick={() => setActiveTab('finance')}>
              Detailed financial sheet →
            </div>
          </div>
        </div>

        {/* Quick Actions & Outstanding Fees */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="text-base font-bold text-slate-900 mb-1">Interactive Quick Actions</h4>
            <p className="text-xs text-slate-500 mb-6">Frequently used modules for school administrators.</p>

            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={() => setActiveTab('students')}
                className="flex items-center gap-3 p-3 text-left rounded-xl border border-blue-50/60 hover:border-blue-100 bg-blue-50/20 hover:bg-blue-50/50 transition-all text-xs"
              >
                <div className="p-2.5 bg-blue-500 text-white rounded-lg">
                  <Users size={16} />
                </div>
                <div>
                  <div className="font-bold text-slate-800">New Student Admission</div>
                  <div className="text-[10px] text-slate-500">Add a student to class listings</div>
                </div>
              </button>

              <button 
                onClick={() => setActiveTab('finance')}
                className="flex items-center gap-3 p-3 text-left rounded-xl border border-emerald-50/60 hover:border-emerald-100 bg-emerald-50/20 hover:bg-emerald-50/50 transition-all text-xs"
              >
                <div className="p-2.5 bg-emerald-500 text-white rounded-lg">
                  <DollarSign size={16} />
                </div>
                <div>
                  <div className="font-bold text-slate-800">Record Fee Collection</div>
                  <div className="text-[10px] text-slate-500">Collect pending fees, print receipt</div>
                </div>
              </button>

              <button 
                onClick={() => setActiveTab('academics')}
                className="flex items-center gap-3 p-3 text-left rounded-xl border border-violet-50/60 hover:border-violet-100 bg-violet-50/20 hover:bg-violet-50/50 transition-all text-xs"
              >
                <div className="p-2.5 bg-violet-500 text-white rounded-lg">
                  <BookOpen size={16} />
                </div>
                <div>
                  <div className="font-bold text-slate-800">Gradebook & Exams</div>
                  <div className="text-[10px] text-slate-500">Upload midterm & final grades</div>
                </div>
              </button>

              <button 
                onClick={() => setActiveTab('communication')}
                className="flex items-center gap-3 p-3 text-left rounded-xl border border-amber-50/60 hover:border-amber-100 bg-amber-50/20 hover:bg-amber-50/50 transition-all text-xs"
              >
                <div className="p-2.5 bg-amber-500 text-white rounded-lg">
                  <Bell size={16} />
                </div>
                <div>
                  <div className="font-bold text-slate-800">Broadcast Announcement</div>
                  <div className="text-[10px] text-slate-500">Send instant Circular / Notice</div>
                </div>
              </button>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100 p-3.5 rounded-xl mt-4 flex items-center gap-3">
            <AlertCircle size={18} className="text-amber-500 shrink-0" />
            <div>
              <div className="text-[11px] font-bold text-slate-700">Audit Status</div>
              <p className="text-[10px] text-slate-500 mt-0.5">
                Outstanding fee deficit is ₹{totalFeesDue.toLocaleString('en-IN')}. Please follow up on defaults.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* HQ Multi-Campus Student Directory & Enrollment Explorer */}
      {selectedBranchId === 'all' && (
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 bg-blue-50 text-blue-600 rounded-lg shrink-0">
                  <Building size={16} />
                </span>
                <h3 className="text-base font-bold text-slate-900 font-sans tracking-tight">
                  HQ Multi-Campus Student Directory Explorer
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Click on any branch card below to instantly audit separate student listings, outstanding dues, and academic grades.
              </p>
            </div>
            
            {/* Search & Filter Inputs */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search student name or roll..."
                  value={explorerSearchTerm}
                  onChange={(e) => setExplorerSearchTerm(e.target.value)}
                  className="bg-slate-50 border border-slate-200 text-slate-800 rounded-lg py-1.5 pl-3 pr-8 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none w-52"
                />
              </div>
              <select
                value={explorerGenderFilter}
                onChange={(e) => setExplorerGenderFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none cursor-pointer"
              >
                <option value="All">All Genders</option>
                <option value="Male">Male Only</option>
                <option value="Female">Female Only</option>
              </select>
            </div>
          </div>

          {/* Interactive Branch Selector Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {branches.map((b) => {
              const bStudents = students.filter(s => s.branchId === b.id);
              const bStaff = staff.filter(st => st.branchId === b.id);
              const isSelected = explorerBranchId === b.id;
              
              return (
                <button
                  key={b.id}
                  onClick={() => {
                    setExplorerBranchId(b.id);
                    setSelectedExplorerStudent(null);
                  }}
                  className={`text-left p-4 rounded-xl border transition-all duration-200 flex flex-col justify-between h-32 relative group overflow-hidden ${
                    isSelected
                      ? 'bg-blue-50/40 border-blue-500 shadow-sm ring-1 ring-blue-500/20'
                      : 'bg-slate-50/30 border-slate-100 hover:border-slate-200 hover:bg-slate-50/70'
                  }`}
                >
                  {/* Subtle color highlight ribbon on top */}
                  <div className="absolute top-0 left-0 right-0 h-1" style={{ backgroundColor: b.color }} />
                  
                  <div>
                    <div className="flex items-center justify-between">
                      <span 
                        className="text-[9px] font-mono uppercase tracking-wider font-extrabold px-1.5 py-0.5 rounded"
                        style={{ 
                          backgroundColor: isSelected ? 'rgba(59,130,246,0.1)' : 'rgba(100,116,139,0.08)',
                          color: isSelected ? '#2563eb' : '#475569'
                        }}
                      >
                        {b.code}
                      </span>
                      <span className="h-1.5 w-1.5 rounded-full animate-ping" style={{ backgroundColor: isSelected ? b.color : 'transparent' }} />
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mt-2 truncate w-full">{b.name}</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5 truncate w-full">Principal: {b.principal}</p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100/80 w-full mt-2">
                    <span className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                      👥 <strong className="text-blue-600">{bStudents.length}</strong> Students
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      🎓 {bStaff.length} Staff
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected Branch Active Directory Table */}
          <div className="bg-slate-50/50 border border-slate-100/80 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  {branches.find(b => b.id === explorerBranchId)?.name} Enrolled Students
                </span>
                <span className="text-[10px] font-mono text-blue-700 bg-blue-50 border border-blue-100 px-2 py-0.5 rounded-md font-semibold">
                  {explorerFilteredStudents.length} Student{explorerFilteredStudents.length !== 1 ? 's' : ''}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                Click "Inspect Report Card" to audit detailed performance & contacts
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-100/80 bg-white shadow-sm">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                    <th className="p-3.5">Roll Number</th>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Class-Section</th>
                    <th className="p-3.5">Parent Details</th>
                    <th className="p-3.5">Fee Clearance</th>
                    <th className="p-3.5">Attendance</th>
                    <th className="p-3.5 text-right">Academic Record</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {explorerFilteredStudents.length > 0 ? (
                    explorerFilteredStudents.map((s) => {
                      const isPaid = s.feesDue === 0;
                      const isPartial = s.feesPaid > 0 && s.feesDue > 0;
                      
                      return (
                        <tr 
                          key={s.id} 
                          className="hover:bg-blue-50/10 transition-colors"
                        >
                          <td className="p-3.5 font-mono font-bold text-slate-600">{s.rollNumber}</td>
                          <td className="p-3.5 font-bold text-slate-900">
                            <div className="flex items-center gap-1.5">
                              <span>{s.name}</span>
                              <span className={`text-[9px] px-1 py-0.5 rounded font-mono font-bold ${
                                s.gender === 'Male' ? 'bg-blue-50 text-blue-600' : 'bg-pink-50 text-pink-600'
                              }`}>
                                {s.gender === 'Male' ? 'M' : 'F'}
                              </span>
                            </div>
                          </td>
                          <td className="p-3.5 text-slate-600 font-bold">{s.class} - {s.section}</td>
                          <td className="p-3.5">
                            <div className="text-slate-800 font-semibold">{s.parentName}</div>
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">{s.parentPhone}</div>
                          </td>
                          <td className="p-3.5">
                            {isPaid ? (
                              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
                                Fully Paid
                              </span>
                            ) : isPartial ? (
                              <span className="bg-amber-50 text-amber-700 border border-amber-200 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
                                ₹{s.feesDue.toLocaleString('en-IN')} Pending
                              </span>
                            ) : (
                              <span className="bg-rose-50 text-rose-700 border border-rose-200 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
                                ₹{s.feesDue.toLocaleString('en-IN')} Unpaid
                              </span>
                            )}
                          </td>
                          <td className="p-3.5">
                            <div className="flex items-center gap-2">
                              <span className={`h-1.5 w-1.5 rounded-full ${
                                s.attendanceRate >= 90 ? 'bg-emerald-500' : s.attendanceRate >= 80 ? 'bg-amber-500' : 'bg-rose-500'
                              }`} />
                              <span className="font-mono font-bold text-slate-700">{s.attendanceRate}%</span>
                            </div>
                          </td>
                          <td className="p-3.5 text-right">
                            <button 
                              onClick={() => setSelectedExplorerStudent(s)}
                              className="text-[11px] font-mono text-blue-600 font-bold bg-blue-50 hover:bg-blue-100 border border-blue-100 px-2.5 py-1 rounded-lg transition-all"
                            >
                              Inspect Report Card
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={7} className="p-10 text-center text-slate-400">
                        No students found matching your filters for this branch.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Student Report & Overview Modal */}
          {selectedExplorerStudent && (
            <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl w-full max-w-2xl p-6 relative animate-in fade-in zoom-in duration-150">
                <button 
                  onClick={() => setSelectedExplorerStudent(null)}
                  className="absolute top-4 right-4 p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <X size={16} />
                </button>

                <div className="flex items-center gap-3.5 pb-4 border-b border-slate-100">
                  <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                    <User size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-lg font-bold text-slate-900">{selectedExplorerStudent.name}</h4>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        selectedExplorerStudent.gender === 'Male' ? 'bg-blue-50 text-blue-600' : 'bg-pink-50 text-pink-600'
                      }`}>
                        {selectedExplorerStudent.gender}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Roll Number: <strong className="font-mono text-slate-700">{selectedExplorerStudent.rollNumber}</strong> | {branches.find(b => b.id === selectedExplorerStudent.branchId)?.name}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-6">
                  {/* Student metadata & Contacts */}
                  <div className="space-y-4">
                    <h5 className="text-[11px] uppercase font-mono font-bold text-slate-400 tracking-wider">Student & Parent Dossier</h5>
                    <div className="bg-slate-50/70 rounded-xl p-4 space-y-3 text-xs border border-slate-100/60">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Class & Section:</span>
                        <span className="font-bold text-slate-800">{selectedExplorerStudent.class} - {selectedExplorerStudent.section}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Date of Birth:</span>
                        <span className="font-mono text-slate-800">{selectedExplorerStudent.dob}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Admission Date:</span>
                        <span className="font-mono text-slate-800">{selectedExplorerStudent.admissionDate || 'N/A'}</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-100/50 pt-2">
                        <span className="text-slate-500">Parent/Guardian:</span>
                        <span className="font-bold text-slate-800">{selectedExplorerStudent.parentName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Parent Phone:</span>
                        <span className="font-mono font-bold text-blue-600">{selectedExplorerStudent.parentPhone}</span>
                      </div>
                      {selectedExplorerStudent.parentEmail && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Parent Email:</span>
                          <span className="font-mono text-slate-600 truncate max-w-[150px]">{selectedExplorerStudent.parentEmail}</span>
                        </div>
                      )}
                      <div className="flex justify-between border-t border-slate-100/50 pt-2">
                        <span className="text-slate-500">Attendance Rate:</span>
                        <span className="font-mono font-bold text-slate-800">{selectedExplorerStudent.attendanceRate}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Academic Grade Breakdown */}
                  <div className="space-y-4">
                    <h5 className="text-[11px] uppercase font-mono font-bold text-slate-400 tracking-wider">Academic Performance</h5>
                    <div className="bg-slate-50/70 rounded-xl p-4 space-y-3 border border-slate-100/60 max-h-56 overflow-y-auto">
                      {selectedExplorerStudent.grades && Object.keys(selectedExplorerStudent.grades).length > 0 ? (
                        Object.entries(selectedExplorerStudent.grades).map(([subject, score]) => {
                          const parsedScore = Number(score);
                          return (
                            <div key={subject} className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span className="text-slate-600 font-medium">{subject}</span>
                                <span className="font-mono font-bold text-slate-900">{parsedScore}/100</span>
                              </div>
                              <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full transition-all ${
                                    parsedScore >= 90 ? 'bg-emerald-500' : parsedScore >= 75 ? 'bg-blue-500' : parsedScore >= 60 ? 'bg-amber-500' : 'bg-rose-500'
                                  }`}
                                  style={{ width: `${parsedScore}%` }}
                                />
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="text-slate-400 text-center py-8 text-xs">
                          No academic records compiled for this term yet.
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs text-slate-500">Total Fees:</span>
                    <span className="text-xs font-mono font-bold text-slate-800">₹{selectedExplorerStudent.feesTotal?.toLocaleString('en-IN')}</span>
                    <span className="text-xs text-slate-400">• Paid:</span>
                    <span className="text-xs font-mono font-bold text-emerald-600">₹{selectedExplorerStudent.feesPaid?.toLocaleString('en-IN')}</span>
                  </div>
                  <button 
                    onClick={() => setSelectedExplorerStudent(null)}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 px-5 rounded-xl text-xs transition-all"
                  >
                    Close Record Audit
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Bottom Panel: Recent Notices & Scheduled Events */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Notices */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="text-base font-bold text-slate-900">ERP Notice Board</h4>
              <p className="text-xs text-slate-500">Sent out to staff, parents, and students.</p>
            </div>
            <button 
              onClick={() => setActiveTab('communication')}
              className="text-xs font-mono text-blue-600 font-semibold hover:underline"
            >
              Manage Notices
            </button>
          </div>

          <div className="space-y-4">
            {notices.slice(0, 3).map((notice) => (
              <div key={notice.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/30 hover:bg-slate-50/60 transition-all">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    notice.priority === 'High' 
                      ? 'bg-rose-50 text-rose-600 border-rose-100 font-bold'
                      : notice.priority === 'Medium'
                      ? 'bg-amber-50 text-amber-600 border-amber-100 font-semibold'
                      : 'bg-blue-50 text-blue-600 border-blue-100'
                  }`}>
                    {notice.priority} Priority Notice
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">{notice.date}</span>
                </div>
                <h5 className="text-xs font-bold text-slate-900">{notice.title}</h5>
                <p className="text-[11px] text-slate-600 mt-1 line-clamp-2 leading-relaxed">{notice.content}</p>
                <div className="mt-3 pt-2.5 border-t border-slate-100/60 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>Scope: <strong className="text-slate-600">{notice.branchId === 'all' ? 'All Campuses' : notice.branchId.toUpperCase()}</strong></span>
                  <span>Sender: <strong className="text-slate-600">{notice.sender}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Academic Calendar & Branch Capacity */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="text-base font-bold text-slate-900 mb-1">Academic & Holiday Calendar</h4>
            <p className="text-xs text-slate-500 mb-4">Scheduled holidays, meetings, and assessments for 2026.</p>

            <div className="space-y-3.5">
              <div className="flex items-center gap-4">
                <div className="h-11 w-11 rounded-xl bg-indigo-50 border border-indigo-100 flex flex-col items-center justify-center font-mono text-indigo-700 shrink-0">
                  <span className="text-[10px] font-bold uppercase leading-none">Jul</span>
                  <span className="text-sm font-black mt-0.5">18</span>
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-950">NEP Implementation Workshop</h5>
                  <p className="text-[10px] text-slate-500 mt-0.5">09:30 AM • Central Campus Assembly Hall</p>
                </div>
                <span className="ml-auto text-[9px] bg-indigo-50 text-indigo-700 border border-indigo-100 px-2 py-0.5 rounded font-mono font-semibold">TEACHERS</span>
              </div>

              <div className="flex items-center gap-4">
                <div className="h-11 w-11 rounded-xl bg-emerald-50 border border-emerald-100 flex flex-col items-center justify-center font-mono text-emerald-700 shrink-0">
                  <span className="text-[10px] font-bold uppercase leading-none">Aug</span>
                  <span className="text-sm font-black mt-0.5">05</span>
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-950">Annual Inter-Branch Sports Meet</h5>
                  <p className="text-[10px] text-slate-500 mt-0.5">PJRS South Campus Sports Complex</p>
                </div>
                <span className="ml-auto text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded font-mono font-semibold">ALL</span>
              </div>

              <div className="flex items-center gap-4">
                <div className="h-11 w-11 rounded-xl bg-rose-50 border border-rose-100 flex flex-col items-center justify-center font-mono text-rose-700 shrink-0">
                  <span className="text-[10px] font-bold uppercase leading-none">Aug</span>
                  <span className="text-sm font-black mt-0.5">15</span>
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-950">Independence Day Celebration</h5>
                  <p className="text-[10px] text-slate-500 mt-0.5">Flag Hoisting and Cultural Programs across all campuses</p>
                </div>
                <span className="ml-auto text-[9px] bg-rose-50 text-rose-700 border border-rose-100 px-2 py-0.5 rounded font-mono font-semibold">HOLIDAY</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100">
            <div className="flex justify-between items-center text-xs mb-1.5 text-slate-600">
              <span className="font-semibold">Consolidated Capacity Utilization</span>
              <span className="font-mono">{studentCount} / {branches.reduce((sum, b) => sum + b.capacity, 0)} Seats ({(studentCount / branches.reduce((sum, b) => sum + b.capacity, 0) * 100).toFixed(1)}%)</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-blue-600 rounded-full" style={{ width: `${(studentCount / branches.reduce((sum, b) => sum + b.capacity, 0) * 100)}%` }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
