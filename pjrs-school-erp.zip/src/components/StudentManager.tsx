import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  User, 
  Phone, 
  Mail, 
  Calendar, 
  Award, 
  Building,
  Activity,
  X,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { Student, Branch, BranchId } from '../types';

interface StudentManagerProps {
  students: Student[];
  branches: Branch[];
  selectedBranchId: BranchId;
  onAddStudent: (newStudent: Student) => void;
  onUpdateStudent: (updatedStudent: Student) => void;
}

export default function StudentManager({
  students,
  branches,
  selectedBranchId,
  onAddStudent,
  onUpdateStudent
}: StudentManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Form State
  const [newName, setNewName] = useState('');
  const [newGender, setNewGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [newClass, setNewClass] = useState('Class 10');
  const [newSection, setNewSection] = useState('A');
  const [newBranch, setNewBranch] = useState(selectedBranchId === 'all' ? 'central' : selectedBranchId);
  const [newDob, setNewDob] = useState('2011-01-01');
  const [newParentName, setNewParentName] = useState('');
  const [newParentPhone, setNewParentPhone] = useState('');
  const [newParentEmail, setNewParentEmail] = useState('');
  const [newStudentEmail, setNewStudentEmail] = useState('');
  const [newStudentPassword, setNewStudentPassword] = useState('student123');
  const [newFeesTotal, setNewFeesTotal] = useState('45000');

  // Filter students
  const filteredStudents = students.filter(s => {
    const matchesBranch = selectedBranchId === 'all' ? true : s.branchId === selectedBranchId;
    const matchesClass = selectedClass === 'all' ? true : s.class === selectedClass;
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.parentName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesBranch && matchesClass && matchesSearch;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newParentName || !newParentPhone) {
      alert('Please fill out Name, Parent Name and Phone number.');
      return;
    }

    const rollNo = `PJRS-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const id = `std_${Date.now()}`;

    // fallback student email if empty
    const fallbackEmail = `${newName.toLowerCase().replace(/\s+/g, '')}@pjrs.org`;

    const newStudentObj: Student = {
      id,
      rollNumber: rollNo,
      name: newName,
      class: newClass,
      section: newSection,
      branchId: newBranch,
      gender: newGender,
      dob: newDob,
      parentName: newParentName,
      parentPhone: newParentPhone,
      parentEmail: newParentEmail,
      email: newStudentEmail.trim() || fallbackEmail,
      password: newStudentPassword || 'student123',
      status: 'Active',
      attendanceRate: 100.0,
      admissionDate: new Date().toISOString().split('T')[0],
      feesTotal: Number(newFeesTotal) || 45000,
      feesPaid: 0,
      feesDue: Number(newFeesTotal) || 45000,
      grades: { Mathematics: 80, Science: 80, English: 80, History: 80, Hindi: 80 }
    };

    onAddStudent(newStudentObj);
    setIsAddModalOpen(false);
    
    // Reset Form
    setNewName('');
    setNewParentName('');
    setNewParentPhone('');
    setNewParentEmail('');
    setNewStudentEmail('');
    setNewStudentPassword('student123');
  };

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans text-slate-900">Student Administration Directory</h2>
          <p className="text-xs text-slate-500 mt-1">
            Search, view, register, or manage student enrollments across schools.
          </p>
        </div>
        <button
          onClick={() => {
            setNewBranch(selectedBranchId === 'all' ? 'central' : selectedBranchId);
            setIsAddModalOpen(true);
          }}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-blue-500/10 transition-all duration-150 self-start md:self-auto"
        >
          <Plus size={16} />
          Register Student
        </button>
      </div>

      {/* Search and Filters panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 border border-slate-100 p-4 rounded-xl">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-slate-400" size={16} />
          <input
            type="text"
            placeholder="Search student or Roll No..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg py-2 pl-9 pr-4 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
          >
            <option value="all">📚 Filter by Grade: All Classes</option>
            <option value="Class 9">Class 9</option>
            <option value="Class 10">Class 10</option>
            <option value="Class 11">Class 11</option>
            <option value="Class 12">Class 12</option>
          </select>
        </div>

        <div className="text-xs text-slate-500 flex items-center justify-end font-mono">
          Showing {filteredStudents.length} of {students.length} Registered Students
        </div>
      </div>

      {/* Student List View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Table/List section */}
        <div className="lg:col-span-2 bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-100">
                  <th className="p-4 font-semibold">Roll No & Student</th>
                  <th className="p-4 font-semibold">Branch & Grade</th>
                  <th className="p-4 font-semibold">Guardian / Contact</th>
                  <th className="p-4 font-semibold">Attendance</th>
                  <th className="p-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredStudents.length > 0 ? (
                  filteredStudents.map((student) => {
                    const branch = branches.find(b => b.id === student.branchId);
                    return (
                      <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="h-9 w-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold font-sans uppercase">
                              {student.name.charAt(0)}
                            </div>
                            <div>
                              <div className="font-bold text-slate-900">{student.name}</div>
                              <div className="text-[10px] text-slate-400 font-mono font-semibold">{student.rollNumber}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="font-semibold text-slate-800">{student.class} - {student.section}</div>
                          <div className="text-[10px] font-medium text-slate-500 flex items-center gap-1 mt-0.5">
                            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: branch?.color }} />
                            {branch?.code}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="text-slate-800 font-medium">{student.parentName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{student.parentPhone}</div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                              <div 
                                className={`h-full rounded-full ${
                                  student.attendanceRate >= 90 
                                    ? 'bg-emerald-500' 
                                    : student.attendanceRate >= 80 
                                    ? 'bg-blue-500' 
                                    : 'bg-rose-500'
                                }`} 
                                style={{ width: `${student.attendanceRate}%` }} 
                              />
                            </div>
                            <span className="font-mono text-[10px] font-bold text-slate-600">{student.attendanceRate}%</span>
                          </div>
                        </td>
                        <td className="p-4 text-right">
                          <button
                            onClick={() => setSelectedStudent(student)}
                            className="bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-600 font-semibold px-2.5 py-1.5 rounded-lg text-[10px] transition-colors"
                          >
                            View Profile
                          </button>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400">
                      No students found matching your filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Student Profile Card (Dynamic sidebar context) */}
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          {selectedStudent ? (
            <div className="space-y-6">
              <div className="flex justify-between items-start">
                <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">Student Profile Details</h4>
                <button onClick={() => setSelectedStudent(null)} className="text-slate-400 hover:text-slate-600">
                  <X size={16} />
                </button>
              </div>

              {/* Profile Avatar / Roll */}
              <div className="text-center pb-4 border-b border-slate-100">
                <div className="h-16 w-16 bg-blue-100 text-blue-700 font-sans font-black text-2xl rounded-2xl flex items-center justify-center mx-auto uppercase">
                  {selectedStudent.name.charAt(0)}
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-3">{selectedStudent.name}</h3>
                <p className="text-[10px] font-mono font-semibold text-slate-400 mt-0.5">{selectedStudent.rollNumber}</p>
                
                <div className="inline-flex items-center gap-1.5 mt-2.5 px-2.5 py-1 rounded-full border bg-emerald-50 text-emerald-700 border-emerald-100 text-[10px] font-mono font-semibold">
                  <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  Active Enrollment
                </div>
              </div>

              {/* Basic Details */}
              <div className="space-y-3.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Campus:</span>
                  <span className="font-semibold text-slate-800">
                    {branches.find(b => b.id === selectedStudent.branchId)?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Class & Section:</span>
                  <span className="font-semibold text-slate-800">{selectedStudent.class} - {selectedStudent.section}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Date of Birth:</span>
                  <span className="font-semibold text-slate-800">{selectedStudent.dob}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Gender:</span>
                  <span className="font-semibold text-slate-800">{selectedStudent.gender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Admission Date:</span>
                  <span className="font-semibold text-slate-800">{selectedStudent.admissionDate}</span>
                </div>
              </div>

              {/* Contact / Parent Section */}
              <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 space-y-2.5 text-xs">
                <div className="font-bold text-slate-900 flex items-center gap-2">
                  <User size={14} className="text-slate-500" />
                  <span>Parent Info: {selectedStudent.parentName}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600">
                  <Phone size={12} className="text-slate-400" />
                  <span className="font-mono">{selectedStudent.parentPhone}</span>
                </div>
                {selectedStudent.parentEmail && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <Mail size={12} className="text-slate-400" />
                    <span className="truncate">{selectedStudent.parentEmail}</span>
                  </div>
                )}
              </div>

              {/* Academic Grades Mini Section */}
              <div>
                <h5 className="font-bold text-xs text-slate-800 mb-2.5 flex items-center gap-2">
                  <Award size={14} className="text-amber-500" />
                  <span>Mid-Term Exam Grades</span>
                </h5>
                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                  {Object.entries(selectedStudent.grades).map(([subject, marks]) => {
                    const score = Number(marks) || 0;
                    return (
                      <div key={subject} className="flex justify-between bg-slate-50 p-2 rounded border border-slate-100">
                        <span className="text-slate-500 font-sans">{subject}</span>
                        <span className={`font-bold ${score >= 80 ? 'text-emerald-600' : 'text-slate-700'}`}>{score}/100</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-20 text-slate-400 space-y-3">
              <User className="mx-auto text-slate-300" size={40} />
              <p className="text-xs">Select a student from the directory to view detailed profile, grades, and parent reports.</p>
            </div>
          )}
        </div>
      </div>

      {/* Add New Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-mono uppercase tracking-wider text-slate-400">ERP Student Registry</h3>
                <h2 className="text-base font-bold font-sans mt-0.5">Register New Admission</h2>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Enter full name"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Gender *</label>
                  <select
                    value={newGender}
                    onChange={(e) => setNewGender(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Grade/Class *</label>
                  <select
                    value={newClass}
                    onChange={(e) => setNewClass(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="Class 9">Class 9</option>
                    <option value="Class 10">Class 10</option>
                    <option value="Class 11">Class 11</option>
                    <option value="Class 12">Class 12</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Section *</label>
                  <select
                    value={newSection}
                    onChange={(e) => setNewSection(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="A">Section A</option>
                    <option value="B">Section B</option>
                    <option value="C">Section C</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Select Campus Branch *</label>
                  <select
                    value={newBranch}
                    onChange={(e) => setNewBranch(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Date of Birth *</label>
                  <input
                    type="date"
                    required
                    value={newDob}
                    onChange={(e) => setNewDob(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-4">
                <h4 className="text-xs font-bold text-slate-900">Parent / Guardian Contact Information</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Parent Name *</label>
                    <input
                      type="text"
                      required
                      value={newParentName}
                      onChange={(e) => setNewParentName(e.target.value)}
                      placeholder="Father's or Mother's name"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Parent Mobile Phone *</label>
                    <input
                      type="text"
                      required
                      value={newParentPhone}
                      onChange={(e) => setNewParentPhone(e.target.value)}
                      placeholder="+91 XXXXX XXXXX"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Parent Email Address</label>
                    <input
                      type="email"
                      value={newParentEmail}
                      onChange={(e) => setNewParentEmail(e.target.value)}
                      placeholder="parent@example.com"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-4">
                <h4 className="text-xs font-bold text-slate-900">Student Portal Login Credentials</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Student Email Gateway</label>
                    <input
                      type="email"
                      value={newStudentEmail}
                      onChange={(e) => setNewStudentEmail(e.target.value)}
                      placeholder="e.g. student@pjrs.org (Optional, defaults to name@pjrs.org)"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Student Password *</label>
                    <input
                      type="text"
                      required
                      value={newStudentPassword}
                      onChange={(e) => setNewStudentPassword(e.target.value)}
                      placeholder="Default is student123"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-4">
                <h4 className="text-xs font-bold text-slate-900">Financial Ledger Settings</h4>
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Annual Academic Fee (INR)</label>
                  <input
                    type="number"
                    value={newFeesTotal}
                    onChange={(e) => setNewFeesTotal(e.target.value)}
                    placeholder="45000"
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-md shadow-blue-500/10 transition-colors"
                >
                  Register and Create Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
