import React, { useState, useEffect } from 'react';
import { 
  Users, 
  BookOpen, 
  Edit, 
  Send, 
  CheckCircle, 
  Plus, 
  Calendar, 
  MessageSquare, 
  Save, 
  X, 
  User, 
  Sparkles,
  Info,
  Clock,
  ArrowRight,
  ClipboardList,
  AlertCircle
} from 'lucide-react';
import { Student, Branch, Staff } from '../types';

interface TeacherPortalProps {
  students: Student[];
  branches: Branch[];
  staffList: Staff[];
  onUpdateStudentGrades: (studentId: string, grades: Record<string, number>) => void;
  activeTeacherTab: string;
  setActiveTeacherTab: (tab: string) => void;
  loggedInTeacherId?: string;
}

interface ChatMessage {
  id: string;
  sender: 'student' | 'teacher';
  text: string;
  timestamp: string;
}

interface TeacherAssignment {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  description: string;
  maxMarks: number;
}

export default function TeacherPortal({
  students,
  branches,
  staffList,
  onUpdateStudentGrades,
  activeTeacherTab,
  setActiveTeacherTab,
  loggedInTeacherId
}: TeacherPortalProps) {
  // Select active teacher from roster to dynamically switch classrooms
  const teachers = staffList.filter(s => s.role === 'Teacher');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>(loggedInTeacherId || teachers[0]?.id || 'staff_01');

  // Keep in sync with loggedInTeacherId
  useEffect(() => {
    if (loggedInTeacherId) {
      setSelectedTeacherId(loggedInTeacherId);
    }
  }, [loggedInTeacherId]);
  const currentTeacher = staffList.find(t => t.id === selectedTeacherId) || teachers[0];

  // Locked context based on selected teacher
  const activeBranchId = currentTeacher?.branchId || 'central';
  const assignedClassDuty = currentTeacher?.assignedClass || 'Class 10-A';
  
  // Extract Class Name & Section
  const [classNameInput, sectionInput] = assignedClassDuty.split('-');
  const activeClass = classNameInput || 'Class 10';
  const activeSection = sectionInput || 'A';

  // State for Gradebook editor
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [mathScore, setMathScore] = useState<string>('');
  const [scienceScore, setScienceScore] = useState<string>('');
  const [englishScore, setEnglishScore] = useState<string>('');
  const [historyScore, setHistoryScore] = useState<string>('');
  const [hindiScore, setHindiScore] = useState<string>('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Assignment states
  const [assignments, setAssignments] = useState<TeacherAssignment[]>([
    {
      id: 'asg_1',
      title: 'Algebra Quadratic Equations Exercises',
      subject: 'Mathematics',
      dueDate: '2026-07-20',
      description: 'Solve exercises 4.1 to 4.4 from your Mathematics textbook. Show all steps clearly.',
      maxMarks: 50
    },
    {
      id: 'asg_2',
      title: 'Physics Refraction and Lenses Lab Report',
      subject: 'Science',
      dueDate: '2026-07-25',
      description: 'Complete the lab observation table for light traveling through glass prisms.',
      maxMarks: 30
    }
  ]);
  const [isAddAsgModalOpen, setIsAddAsgModalOpen] = useState(false);
  const [asgTitle, setAsgTitle] = useState('');
  const [asgSubject, setAsgSubject] = useState(currentTeacher?.subjectSpecialty || 'General');
  const [asgDue, setAsgDue] = useState('2026-07-20');
  const [asgDesc, setAsgDesc] = useState('');
  const [asgMaxMarks, setAsgMaxMarks] = useState('50');

  // Chat states
  const [selectedChatStudentId, setSelectedChatStudentId] = useState<string>('');
  const [typedMessage, setTypedMessage] = useState('');
  const [chats, setChats] = useState<Record<string, ChatMessage[]>>(() => {
    const saved = localStorage.getItem('pjrs_erp_student_chats');
    return saved ? JSON.parse(saved) : {};
  });

  // Sync back to localstorage whenever chats update
  useEffect(() => {
    localStorage.setItem('pjrs_erp_student_chats', JSON.stringify(chats));
  }, [chats]);

  // Synchronize chats from localStorage when the chat tab is opened
  useEffect(() => {
    if (activeTeacherTab === 'chat') {
      const saved = localStorage.getItem('pjrs_erp_student_chats');
      if (saved) {
        try {
          setChats(JSON.parse(saved));
        } catch (e) {
          console.error(e);
        }
      }
    }
  }, [activeTeacherTab, selectedTeacherId, selectedChatStudentId]);

  // Load selected student grades into gradebook editor inputs
  const handleSelectStudentForGrades = (studentId: string) => {
    const s = students.find(x => x.id === studentId);
    if (s) {
      setSelectedStudentId(s.id);
      setMathScore(String(s.grades.Mathematics ?? ''));
      setScienceScore(String(s.grades.Science ?? ''));
      setEnglishScore(String(s.grades.English ?? ''));
      setHistoryScore(String(s.grades.History ?? ''));
      setHindiScore(String(s.grades.Hindi ?? ''));
      setSaveSuccess(false);
    }
  };

  // Filter students by current teacher's branch and class duty
  const classStudents = students.filter(s => 
    s.branchId === activeBranchId && 
    s.class.toLowerCase() === activeClass.toLowerCase() && 
    s.section.toLowerCase() === activeSection.toLowerCase()
  );

  // Expanded student list in the same branch for dynamic campus chat room
  const chatStudents = students.filter(s => s.branchId === activeBranchId);

  // Set default selected student for grades and chats on load
  useEffect(() => {
    if (classStudents.length > 0) {
      if (!selectedStudentId || !classStudents.some(cs => cs.id === selectedStudentId)) {
        handleSelectStudentForGrades(classStudents[0].id);
      }
    }
    const availableChatStudents = chatStudents.length > 0 ? chatStudents : students;
    if (availableChatStudents.length > 0) {
      if (!selectedChatStudentId || !availableChatStudents.some(cs => cs.id === selectedChatStudentId)) {
        setSelectedChatStudentId(availableChatStudents[0].id);
      }
    }
  }, [selectedTeacherId, students]);

  if (!currentTeacher) {
    return <div className="p-8 text-center text-slate-500">No active teacher profiles.</div>;
  }

  const activeBranch = branches.find(b => b.id === activeBranchId);

  // Submit Gradebook update
  const handleSaveGrades = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentId) return;

    const gradesPayload = {
      Mathematics: Number(mathScore) || 0,
      Science: Number(scienceScore) || 0,
      English: Number(englishScore) || 0,
      History: Number(historyScore) || 0,
      Hindi: Number(hindiScore) || 0,
    };

    onUpdateStudentGrades(selectedStudentId, gradesPayload);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 4000);
  };

  // Submit Add Assignment
  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!asgTitle || !asgDesc) {
      alert('Please fill out Title and Description.');
      return;
    }

    const newAsg: TeacherAssignment = {
      id: `asg_${Date.now()}`,
      title: asgTitle,
      subject: asgSubject,
      dueDate: asgDue,
      description: asgDesc,
      maxMarks: Number(asgMaxMarks) || 50
    };

    setAssignments(prev => [...prev, newAsg]);
    setIsAddAsgModalOpen(false);

    // reset
    setAsgTitle('');
    setAsgDesc('');
    alert(`📢 Assignment published successfully to Class ${assignedClassDuty}!`);
  };

  // Submit Send Chat
  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMessage.trim() || !selectedChatStudentId) return;

    const chatKey = `${selectedChatStudentId}_${currentTeacher.id}`;
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'teacher',
      text: typedMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChats(prev => ({
      ...prev,
      [chatKey]: [...(prev[chatKey] || []), newMsg]
    }));

    setTypedMessage('');

    // Simulate student automated response after 1.5s
    const availableChatStudents = chatStudents.length > 0 ? chatStudents : students;
    const targetStudentName = availableChatStudents.find(s => s.id === selectedChatStudentId)?.name || 'Student';
    setTimeout(() => {
      const studentReplies = [
        `Thank you for explaining, Ma'am. I will submit the revised sheet shortly.`,
        `Understood, Ma'am. I will clarify my doubt in the extra class tomorrow.`,
        `Okay Ma'am, I have noted the correction. I will share it with my parents too.`,
        `Yes Ma'am, I have uploaded the assignment on the portal. Please review it.`,
        `I apologize for the delay. I will make sure to finish it by tonight.`
      ];
      const randomReply = studentReplies[Math.floor(Math.random() * studentReplies.length)];

      const studentMsg: ChatMessage = {
        id: `msg_reply_${Date.now()}`,
        sender: 'student',
        text: randomReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setChats(prev => ({
        ...prev,
        [chatKey]: [...(prev[chatKey] || []), studentMsg]
      }));
    }, 1500);
  };

  const currentChatKey = `${selectedChatStudentId}_${currentTeacher.id}`;
  const activeChatHistory = chats[currentChatKey] || [];

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto animate-in fade-in duration-150">
      
      {/* Teacher Profile Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white border border-slate-100 p-6 rounded-2xl shadow-sm gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-blue-50 text-blue-600 text-[10px] uppercase font-mono px-2 py-0.5 rounded border border-blue-100 font-bold tracking-wider">
              Faculty ERP Portal
            </span>
            <span className="text-slate-400 text-xs font-mono">• Academic Year: 2026-2027</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 font-sans">Faculty Classroom Dashboard</h2>
          <p className="text-xs text-slate-500 mt-1">
            Publish syllabus milestones, grade midterm exam rosters, and exchange real-time learning updates with pupils.
          </p>
        </div>

        {/* Dynamic Teacher Switcher (Simulated logins for easier grading testing) */}
        <div className="flex items-center gap-3 bg-slate-50 border border-slate-100 p-3 rounded-xl min-w-[300px]">
          <div className="bg-blue-600 text-white p-2.5 rounded-lg">
            <Users size={18} />
          </div>
          <div className="flex-1">
            <label className="text-[9px] uppercase font-mono font-bold text-slate-400 block">
              {loggedInTeacherId ? 'Active Logged In Faculty' : 'Active Faculty Duty Profile'}
            </label>
            {loggedInTeacherId ? (
              <span className="text-xs font-bold text-slate-800 block mt-0.5 truncate">
                {currentTeacher.name} ({currentTeacher.assignedClass || 'Subject teacher'})
              </span>
            ) : (
              <select
                value={selectedTeacherId}
                onChange={(e) => {
                  setSelectedTeacherId(e.target.value);
                  setSelectedStudentId('');
                  setSelectedChatStudentId('');
                }}
                className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none w-full p-0 cursor-pointer"
              >
                {teachers.map(t => (
                  <option key={t.id} value={t.id}>{t.name} ({t.assignedClass || 'Subject teacher'})</option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Classroom Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
          <span className="text-[10px] uppercase font-mono text-slate-400 font-bold">Class Assignment Scope</span>
          <h4 className="text-lg font-black text-slate-950 mt-1">{assignedClassDuty}</h4>
          <p className="text-xs text-slate-500 mt-1">Specialty: <strong>{currentTeacher.subjectSpecialty || 'General'}</strong></p>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
          <span className="text-[10px] uppercase font-mono text-slate-400 font-bold">Registered Class Roll</span>
          <h4 className="text-lg font-black text-slate-950 mt-1">{classStudents.length} Students</h4>
          <p className="text-xs text-slate-500 mt-1">Campus: <strong>{activeBranch?.name}</strong></p>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm">
          <span className="text-[10px] uppercase font-mono text-slate-400 font-bold">Class Avg. Attendance</span>
          <h4 className="text-lg font-black text-emerald-600 mt-1">
            {classStudents.length > 0 
              ? `${(classStudents.reduce((sum, s) => sum + s.attendanceRate, 0) / classStudents.length).toFixed(1)}%`
              : '0%'
            }
          </h4>
          <p className="text-xs text-slate-500 mt-1">Target Threshold: <strong>85.0% Min</strong></p>
        </div>
      </div>

      {/* Portal Tabs */}
      <div className="flex border-b border-slate-200 gap-1 overflow-x-auto pb-px">
        {[
          { id: 'classroom', label: 'Classroom Registry', icon: ClipboardList },
          { id: 'gradebook', label: 'Mid-Term Exam Gradebook', icon: Edit },
          { id: 'assignments', label: 'Assignment Planner', icon: BookOpen },
          { id: 'chat', label: 'Student Chat Room', icon: MessageSquare },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTeacherTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTeacherTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
                isActive 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ACTIVE TAB RENDER */}

      {/* CLASSROOM REGISTRY */}
      {activeTeacherTab === 'classroom' && (
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm p-6 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Registered Students in Class {assignedClassDuty}</h3>
              <p className="text-[11px] text-slate-500">Full roster of enrolled pupils for the active campus branch.</p>
            </div>
            <span className="text-xs font-mono font-bold text-slate-500 bg-slate-50 border border-slate-100 px-3 py-1 rounded-md">
              Total Roster: {classStudents.length}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="py-3 px-2">Roll Number</th>
                  <th className="py-3 px-2">Student Name</th>
                  <th className="py-3 px-2">Parent Contact</th>
                  <th className="py-3 px-2 text-center">Attendance</th>
                  <th className="py-3 px-2 text-right">Tuition Balance</th>
                  <th className="py-3 px-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {classStudents.map(student => (
                  <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3.5 px-2 font-mono text-slate-500 font-medium">{student.rollNumber}</td>
                    <td className="py-3.5 px-2 font-bold text-slate-800">{student.name}</td>
                    <td className="py-3.5 px-2">
                      <div className="font-medium text-slate-700">{student.parentName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{student.parentPhone}</div>
                    </td>
                    <td className="py-3.5 px-2 text-center">
                      <span className={`font-mono font-bold ${student.attendanceRate >= 85 ? 'text-emerald-600' : 'text-amber-500'}`}>
                        {student.attendanceRate}%
                      </span>
                    </td>
                    <td className="py-3.5 px-2 text-right font-mono font-semibold text-slate-600">
                      ₹{student.feesDue.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3.5 px-2 text-right">
                      <div className="flex gap-2 justify-end">
                        <button
                          onClick={() => {
                            setActiveTeacherTab('gradebook');
                            handleSelectStudentForGrades(student.id);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-1 rounded text-[10px] font-semibold transition-colors"
                        >
                          Grade Mid-Term
                        </button>
                        <button
                          onClick={() => {
                            setActiveTeacherTab('chat');
                            setSelectedChatStudentId(student.id);
                          }}
                          className="bg-blue-50 hover:bg-blue-100 text-blue-600 px-2 py-1 rounded text-[10px] font-bold transition-colors"
                        >
                          Chat
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {classStudents.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center text-slate-400 py-10">No students found registered under this teacher's class-section code.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* GRADEBOOK EDITOR */}
      {activeTeacherTab === 'gradebook' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Student Selector list */}
          <div className="lg:col-span-4 bg-white border border-slate-100 rounded-2xl p-4 shadow-sm space-y-4">
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">Class Roster</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">Select a student below to update active grades.</p>
            </div>

            <div className="space-y-1.5 max-h-[380px] overflow-y-auto">
              {classStudents.map(student => {
                const isSelected = selectedStudentId === student.id;
                const gradesArray = Object.values(student.grades);
                const isGraded = gradesArray.length > 0;
                return (
                  <button
                    key={student.id}
                    type="button"
                    onClick={() => handleSelectStudentForGrades(student.id)}
                    className={`w-full text-left p-3 rounded-xl border text-xs flex items-center justify-between transition-all ${
                      isSelected 
                        ? 'bg-blue-50 border-blue-500/30 text-blue-900 shadow-3xs' 
                        : 'bg-transparent border-transparent text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <div className="font-bold">{student.name}</div>
                      <p className="text-[9px] text-slate-400 font-mono mt-0.5">{student.rollNumber}</p>
                    </div>

                    {isGraded ? (
                      <span className="bg-emerald-50 text-emerald-700 text-[9px] font-bold px-1.5 py-0.5 rounded border border-emerald-100 uppercase font-mono">
                        Graded
                      </span>
                    ) : (
                      <span className="bg-amber-50 text-amber-700 text-[9px] font-bold px-1.5 py-0.5 rounded border border-amber-100 uppercase font-mono">
                        Pending
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Marks Editor */}
          <div className="lg:col-span-8 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
            {selectedStudentId ? (
              (() => {
                const sObj = classStudents.find(st => st.id === selectedStudentId);
                return (
                  <form onSubmit={handleSaveGrades} className="space-y-6">
                    <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                      <div>
                        <span className="text-[10px] uppercase font-mono text-slate-400 font-bold">Active Evaluation Sheet</span>
                        <h3 className="text-sm font-black text-slate-900 mt-1">{sObj?.name} ({sObj?.rollNumber})</h3>
                      </div>
                      <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-1 rounded font-mono font-bold uppercase border border-indigo-100">
                        Class {sObj?.class}-{sObj?.section} Marks
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { subject: 'Mathematics', val: mathScore, setVal: setMathScore },
                        { subject: 'Science', val: scienceScore, setVal: setScienceScore },
                        { subject: 'English', val: englishScore, setVal: setEnglishScore },
                        { subject: 'History', val: historyScore, setVal: setHistoryScore },
                        { subject: 'Hindi', val: hindiScore, setVal: setHindiScore },
                      ].map(field => (
                        <div key={field.subject} className="space-y-1.5 bg-slate-50/50 p-3.5 rounded-xl border border-slate-100">
                          <label className="text-[11px] font-bold text-slate-600 block">{field.subject} (Marks Scored)</label>
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              required
                              max="100"
                              min="0"
                              value={field.val}
                              onChange={(e) => field.setVal(e.target.value)}
                              placeholder="Enter score"
                              className="w-full bg-white border border-slate-200 text-slate-800 rounded-lg p-2 text-xs font-bold focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                            />
                            <span className="text-xs text-slate-400 font-mono">/ 100</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {saveSuccess && (
                      <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-700 text-[11px] font-bold flex items-center gap-1">
                        <CheckCircle size={14} /> Grades successfully published and locked into parent ledger.
                      </div>
                    )}

                    <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                      <button
                        type="button"
                        onClick={() => handleSelectStudentForGrades(selectedStudentId)}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2 rounded-lg text-xs font-semibold transition-colors"
                      >
                        Reset Marks
                      </button>
                      <button
                        type="submit"
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded-lg text-xs shadow-md shadow-blue-500/10 transition-colors flex items-center gap-1.5"
                      >
                        <Save size={14} /> Commit & Publish Grades
                      </button>
                    </div>
                  </form>
                );
              })()
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs py-16 gap-2">
                <Edit size={32} className="text-slate-300 animate-bounce" />
                <span>Select a student from the left roster list to load their mark sheet.</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ASSIGNMENT PLANNER */}
      {activeTeacherTab === 'assignments' && (
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Coursework Assignments & Briefings</h3>
              <p className="text-[11px] text-slate-500">Design homework briefs, set submission locks, and inspect active completions.</p>
            </div>
            <button
              onClick={() => setIsAddAsgModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus size={14} /> Create Assignment Brief
            </button>
          </div>

          <div className="space-y-4">
            {assignments.map(asg => (
              <div key={asg.id} className="p-5 border border-slate-100 rounded-2xl bg-slate-50/40 hover:bg-slate-50 transition-all space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100/60">
                  <div>
                    <span className="text-[9px] font-mono uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-50 text-blue-600 border border-blue-100">
                      {asg.subject}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 mt-2">{asg.title}</h4>
                  </div>
                  <div className="text-[10px] font-mono text-slate-500 flex flex-col items-end">
                    <span>Grading Max: <strong>{asg.maxMarks} Marks</strong></span>
                    <span className="text-rose-500 font-bold flex items-center gap-1 mt-1">
                      <Clock size={11} /> Deadline: {asg.dueDate}
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-600 leading-relaxed">{asg.description}</p>

                <div className="pt-2 border-t border-slate-100/60 flex justify-between items-center text-[10px] text-slate-500 font-mono">
                  <span>Duty Target: <strong>Class {assignedClassDuty}</strong></span>
                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle size={12} /> Live / Open for Submissions
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Add Assignment Modal */}
          {isAddAsgModalOpen && (
            <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
                <div className="bg-slate-900 text-white p-5 flex justify-between items-center">
                  <div>
                    <h3 className="text-[10px] font-mono uppercase text-slate-400 font-bold">Class Assignment Planner</h3>
                    <h2 className="text-sm font-bold font-sans mt-0.5">Publish Homework Brief</h2>
                  </div>
                  <button onClick={() => setIsAddAsgModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                    <X size={18} />
                  </button>
                </div>

                <form onSubmit={handleCreateAssignment} className="p-6 space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Assignment Title *</label>
                    <input
                      type="text"
                      required
                      value={asgTitle}
                      onChange={(e) => setAsgTitle(e.target.value)}
                      placeholder="e.g. Algebra Practice Questions"
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Subject *</label>
                      <input
                        type="text"
                        required
                        value={asgSubject}
                        onChange={(e) => setAsgSubject(e.target.value)}
                        placeholder="Math, Science..."
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Max Marks *</label>
                      <input
                        type="number"
                        required
                        value={asgMaxMarks}
                        onChange={(e) => setAsgMaxMarks(e.target.value)}
                        placeholder="50"
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Due Date *</label>
                    <input
                      type="date"
                      required
                      value={asgDue}
                      onChange={(e) => setAsgDue(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Detailed Brief / Instructions *</label>
                    <textarea
                      required
                      rows={3}
                      value={asgDesc}
                      onChange={(e) => setAsgDesc(e.target.value)}
                      placeholder="List down textbook pages, reference links, and grading guidelines..."
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none resize-none"
                    />
                  </div>

                  <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsAddAsgModalOpen(false)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-2 rounded-lg text-xs font-semibold transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-lg text-xs shadow-md shadow-blue-500/10 transition-colors"
                    >
                      Publish Assignment
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CHAT ROOM */}
      {activeTeacherTab === 'chat' && (
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[480px]">
          {/* Pupils list */}
          <div className="md:col-span-4 border-r border-slate-100 bg-slate-50/50 p-4 space-y-4">
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">Class Pupil List</h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Select a pupil in your class to chat.</p>
            </div>

            <div className="space-y-1.5 max-h-[360px] overflow-y-auto">
              {(chatStudents.length > 0 ? chatStudents : students).map(student => {
                const isSelected = selectedChatStudentId === student.id;
                return (
                  <button
                    key={student.id}
                    onClick={() => setSelectedChatStudentId(student.id)}
                    className={`w-full text-left p-3 rounded-xl border text-xs flex items-center gap-3 transition-all ${
                      isSelected 
                        ? 'bg-white border-blue-500/30 text-blue-900 shadow-3xs' 
                        : 'bg-transparent border-transparent text-slate-600 hover:bg-slate-200/50'
                    }`}
                  >
                    <div className="h-9 w-9 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold font-mono">
                      {student.name.split(' ')[0][0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold truncate">{student.name}</div>
                      <p className="text-[10px] text-slate-400 font-mono truncate">{student.rollNumber}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Chat Pane */}
          <div className="md:col-span-8 flex flex-col justify-between min-h-[400px]">
            {selectedChatStudentId ? (
              (() => {
                const availableChatStudents = chatStudents.length > 0 ? chatStudents : students;
                const sObj = availableChatStudents.find(st => st.id === selectedChatStudentId);
                return (
                  <>
                    <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold font-mono text-xs">
                          {sObj?.name.split(' ')[0][0]}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">{sObj?.name}</h4>
                          <span className="text-[9px] bg-indigo-50 text-indigo-700 font-mono px-1.5 py-0.5 rounded font-bold uppercase block w-max mt-0.5">
                            Roll Number: {sObj?.rollNumber}
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-500 font-mono font-bold flex items-center gap-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> STUDENT PORTAL ACTIVE
                      </span>
                    </div>

                    {/* Messages Scroll Panel */}
                    <div className="flex-1 p-6 space-y-4 max-h-[320px] overflow-y-auto bg-slate-50/20">
                      {activeChatHistory.length > 0 ? (
                        activeChatHistory.map(msg => {
                          const isTeacher = msg.sender === 'teacher';
                          return (
                            <div key={msg.id} className={`flex ${isTeacher ? 'justify-end' : 'justify-start'}`}>
                              <div className={`max-w-md rounded-2xl p-3.5 text-xs shadow-3xs ${
                                isTeacher 
                                  ? 'bg-blue-600 text-white rounded-tr-none' 
                                  : 'bg-white border border-slate-100 text-slate-800 rounded-tl-none'
                              }`}>
                                <p className="leading-relaxed">{msg.text}</p>
                                <span className={`text-[9px] font-mono mt-1 block text-right ${
                                  isTeacher ? 'text-blue-200' : 'text-slate-400'
                                }`}>
                                  {msg.timestamp}
                                </span>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs py-12 gap-2">
                          <MessageSquare size={32} className="text-slate-300" />
                          <span>No conversation history yet. Send an update or homework instruction!</span>
                        </div>
                      )}
                    </div>

                    {/* Send Message Input */}
                    <form onSubmit={handleSendChat} className="p-4 border-t border-slate-100 flex gap-2">
                      <input
                        type="text"
                        value={typedMessage}
                        onChange={(e) => setTypedMessage(e.target.value)}
                        placeholder={`Type message to ${sObj?.name || 'student'}...`}
                        className="flex-1 bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                      <button
                        type="submit"
                        className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl transition-colors shrink-0"
                      >
                        <Send size={16} />
                      </button>
                    </form>
                  </>
                );
              })()
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400 text-xs gap-2">
                <User size={32} className="text-slate-300 animate-pulse" />
                <span>Select a class pupil from the left list.</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
