import React, { useState } from 'react';
import { 
  School, 
  LogIn, 
  UserPlus, 
  ShieldCheck, 
  BookOpen, 
  User, 
  KeyRound, 
  Sparkles, 
  AlertCircle,
  CheckCircle2,
  MapPin,
  Mail,
  UserCheck,
  ChevronRight
} from 'lucide-react';
import { Student, Staff, Branch, UserRole, BranchId } from '../types';

interface LoginScreenProps {
  students: Student[];
  staffList: Staff[];
  branches: Branch[];
  onAddStudent: (newStudent: Student) => void;
  onAddStaff: (newStaff: Staff) => void;
  onLoginSuccess: (role: UserRole, userPayload: any) => void;
}

export default function LoginScreen({
  students,
  staffList,
  branches,
  onAddStudent,
  onAddStaff,
  onLoginSuccess
}: LoginScreenProps) {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  
  // Login Form States
  const [loginRole, setLoginRole] = useState<UserRole>('super_admin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Registration Form States
  const [regRole, setRegRole] = useState<'student' | 'teacher'>('student');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regBranch, setRegBranch] = useState('central');
  
  // Student Specific Reg States
  const [regClass, setRegClass] = useState('Class 10');
  const [regSection, setRegSection] = useState('A');
  const [regParentName, setRegParentName] = useState('');
  const [regParentPhone, setRegParentPhone] = useState('');
  const [regParentEmail, setRegParentEmail] = useState('');
  const [regGender, setRegGender] = useState<'Male' | 'Female' | 'Other'>('Male');

  // Teacher Specific Reg States
  const [regPhone, setRegPhone] = useState('');
  const [regQual, setRegQual] = useState('');
  const [regSpecialty, setRegSpecialty] = useState('');
  const [regAssignedClass, setRegAssignedClass] = useState('Class 10-A');

  // Quick Login demo helper
  const handleQuickLogin = (role: UserRole) => {
    setLoginRole(role);
    setErrorMsg('');
    if (role === 'super_admin') {
      setEmail('hq@pjrs.org');
      setPassword('hq123');
    } else if (role === 'branch_admin') {
      setEmail('branch@pjrs.org');
      setPassword('branch123');
    } else if (role === 'teacher') {
      setEmail('suman.sharma@pjrs.org');
      setPassword('teacher123');
    } else if (role === 'student') {
      setEmail('aarav@pjrs.org');
      setPassword('student123');
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const normalizedEmail = email.trim().toLowerCase();

    // 1. HQ Admin (Super Admin) Validation
    if (loginRole === 'super_admin') {
      if ((normalizedEmail === 'hq@pjrs.org' || normalizedEmail === 'admin@pjrs.org') && (password === 'hq123' || password === 'admin123')) {
        setSuccessMsg('Access Granted! Redirecting to Group HQ Admin Ledger...');
        setTimeout(() => {
          onLoginSuccess('super_admin', { name: 'HQ Group Admin', email: 'hq@pjrs.org', branchId: 'all' });
        }, 1000);
      } else {
        setErrorMsg('Invalid HQ Admin credentials. Hint: use hq@pjrs.org / hq123');
      }
      return;
    }

    // 1b. Branch Admin Validation
    if (loginRole === 'branch_admin') {
      if (normalizedEmail === 'branch@pjrs.org' && password === 'branch123') {
        setSuccessMsg('Access Granted! Redirecting to Central Branch Admin Ledger...');
        setTimeout(() => {
          onLoginSuccess('branch_admin', { name: 'Central Branch Admin', email: 'branch@pjrs.org', branchId: 'central' });
        }, 1000);
      } else {
        // Check if matching any school Principal email
        const foundPrincipal = staffList.find(
          s => (s.role === 'Principal' || s.role === 'Admin') && s.email.trim().toLowerCase() === normalizedEmail
        );
        if (foundPrincipal) {
          const expectedPassword = foundPrincipal.password || 'teacher123';
          if (password === expectedPassword) {
            setSuccessMsg(`Welcome Back, ${foundPrincipal.name}! Loading ${foundPrincipal.branchId.toUpperCase()} Branch Admin Portal...`);
            setTimeout(() => {
              onLoginSuccess('branch_admin', { name: foundPrincipal.name, email: foundPrincipal.email, branchId: foundPrincipal.branchId });
            }, 1000);
          } else {
            setErrorMsg('Incorrect password. Hint: default password is teacher123');
          }
        } else {
          setErrorMsg('Invalid Branch Admin credentials. Hint: use branch@pjrs.org / branch123');
        }
      }
      return;
    }

    // 2. Teacher (Staff) Portal Validation
    if (loginRole === 'teacher') {
      const foundTeacher = staffList.find(
        s => s.role === 'Teacher' && s.email.trim().toLowerCase() === normalizedEmail
      );
      if (foundTeacher) {
        // Match explicit password or default
        const expectedPassword = foundTeacher.password || 'teacher123';
        if (password === expectedPassword) {
          setSuccessMsg(`Welcome Back, ${foundTeacher.name}! Loading faculty portal...`);
          setTimeout(() => {
            onLoginSuccess('teacher', foundTeacher);
          }, 1000);
        } else {
          setErrorMsg('Incorrect password. Hint: default password is teacher123');
        }
      } else {
        setErrorMsg('No registered teacher found with this email.');
      }
      return;
    }

    // 3. Student Portal Validation
    if (loginRole === 'student') {
      const foundStudent = students.find(s => {
        const fallbackEmail = s.email || `${s.name.trim().split(' ')[0].toLowerCase()}@pjrs.org`;
        const emailMatch = fallbackEmail.trim().toLowerCase() === normalizedEmail;
        const rollMatch = s.rollNumber.trim().toUpperCase() === normalizedEmail.toUpperCase();
        return emailMatch || rollMatch;
      });
      if (foundStudent) {
        const expectedPassword = foundStudent.password || 'student123';
        if (password === expectedPassword) {
          // ensure email and password are set on the object passed back
          const studentWithCreds = {
            ...foundStudent,
            email: foundStudent.email || `${foundStudent.name.trim().split(' ')[0].toLowerCase()}@pjrs.org`,
            password: expectedPassword
          };
          setSuccessMsg(`Welcome Back, ${foundStudent.name}! Loading marksheets and outstanding dues...`);
          setTimeout(() => {
            onLoginSuccess('student', studentWithCreds);
          }, 1000);
        } else {
          setErrorMsg('Incorrect password. Hint: default password is student123');
        }
      } else {
        setErrorMsg('No student match found for this email/roll number. Try "aarav@pjrs.org" or roll "PJRS-2026-1001"');
      }
      return;
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!regName || !regEmail || !regPassword) {
      setErrorMsg('Please fill out Name, Email, and Password.');
      return;
    }

    const normalizedEmail = regEmail.trim().toLowerCase();

    // Check duplicate email
    if (regRole === 'student') {
      if (students.some(s => s.email?.toLowerCase() === normalizedEmail)) {
        setErrorMsg('This student email is already registered.');
        return;
      }

      // Generate credentials
      const rollNo = `PJRS-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const studentId = `std_${Date.now()}`;
      const newStudent: Student = {
        id: studentId,
        rollNumber: rollNo,
        name: regName,
        class: regClass,
        section: regSection,
        branchId: regBranch,
        gender: regGender,
        dob: '2011-04-12',
        parentName: regParentName || `${regName.split(' ')[0]}'s Parent`,
        parentPhone: regParentPhone || '+91 98123 45678',
        parentEmail: regParentEmail || `${normalizedEmail.split('@')[0]}.parent@pjrs.org`,
        email: normalizedEmail,
        password: regPassword,
        status: 'Active',
        attendanceRate: 95.0,
        admissionDate: new Date().toISOString().split('T')[0],
        feesTotal: 45000,
        feesPaid: 0,
        feesDue: 45000,
        grades: { Mathematics: 85, Science: 82, English: 90, History: 78, Hindi: 88 }
      };

      onAddStudent(newStudent);
      setSuccessMsg(`Registration Successful! Student Roll: ${rollNo}. Logging in...`);
      setTimeout(() => {
        onLoginSuccess('student', newStudent);
      }, 1500);

    } else {
      // Teacher
      if (staffList.some(s => s.email.toLowerCase() === normalizedEmail)) {
        setErrorMsg('This faculty email is already registered.');
        return;
      }

      const empId = `PJRS-EMP-${Math.floor(100 + Math.random() * 900)}`;
      const staffId = `staff_${Date.now()}`;
      const newTeacher: Staff = {
        id: staffId,
        empId,
        name: regName,
        role: 'Teacher',
        branchId: regBranch,
        email: normalizedEmail,
        password: regPassword,
        phone: regPhone || '+91 99999 88888',
        salary: 48000,
        salaryStatus: 'Pending',
        qualification: regQual || 'Post Graduate, B.Ed.',
        joiningDate: new Date().toISOString().split('T')[0],
        subjectSpecialty: regSpecialty || 'General',
        assignedClass: regAssignedClass
      };

      onAddStaff(newTeacher);
      setSuccessMsg(`Registration Successful! Employee ID: ${empId}. Logging in...`);
      setTimeout(() => {
        onLoginSuccess('teacher', newTeacher);
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4 md:p-8 overflow-y-auto relative selection:bg-blue-600 selection:text-white">
      
      {/* Dynamic Background Accents */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full filter blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full filter blur-3xl pointer-events-none" />

      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative z-10 my-8">
        
        {/* Left Informative Panel */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 p-8 md:p-12 flex flex-col justify-between border-r border-slate-800">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="bg-blue-600 p-3 rounded-2xl shadow-lg shadow-blue-500/20 text-white">
                <School size={28} />
              </div>
              <div>
                <h1 className="text-xl font-bold font-sans text-white tracking-tight">PJRS Group</h1>
                <p className="text-[10px] uppercase font-mono tracking-wider text-blue-400 font-bold">Multi-Campus ERP Ledger</p>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-2xl font-black text-slate-100 tracking-tight leading-tight">
                Empowering Smart School Administration & Student Portals
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                Connect and manage tuition payments, exam reports, assignment planners, and real-time messaging from a single secure portal.
              </p>

              <div className="space-y-4 pt-4">
                <div className="flex items-start gap-3.5">
                  <div className="p-1.5 bg-blue-950 border border-blue-900 text-blue-400 rounded-lg mt-0.5">
                    <ShieldCheck size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Role-Based Gateways</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Strict separation between HQ Super Admin, Faculty Desk, and Student portals.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-1.5 bg-emerald-950 border border-emerald-900 text-emerald-400 rounded-lg mt-0.5">
                    <CheckCircle2 size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Store & Fees Clearance</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Students can pay dues via mock UPI/Netbanking and buy school uniform assets.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-800/80 mt-12">
            <span className="text-[10px] font-mono text-slate-500 block">Enterprise Domain Locked:</span>
            <span className="text-xs font-mono font-bold text-slate-300">pjrs.org • Delhi NCR Group</span>
          </div>
        </div>

        {/* Right Active Form Panel */}
        <div className="lg:col-span-7 bg-slate-900/40 p-6 md:p-10 flex flex-col justify-between">
          
          {/* Form Tabs Selector */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
            <div className="flex gap-2">
              <button
                onClick={() => { setActiveTab('login'); setErrorMsg(''); setSuccessMsg(''); }}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                  activeTab === 'login' 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                }`}
              >
                Sign In
              </button>
              <button
                onClick={() => { setActiveTab('register'); setErrorMsg(''); setSuccessMsg(''); }}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
                  activeTab === 'register' 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                }`}
              >
                Create Account
              </button>
            </div>
            <span className="text-[10px] text-slate-500 bg-slate-800/60 border border-slate-800 px-2.5 py-1 rounded font-mono uppercase tracking-wider">
              {activeTab === 'login' ? 'Auth Verification' : 'Portal Enrollment'}
            </span>
          </div>

          {/* Messages Alert */}
          {errorMsg && (
            <div className="p-3 bg-red-950/40 border border-red-900/60 rounded-xl text-red-400 text-xs flex items-center gap-2 mb-4 font-semibold">
              <AlertCircle size={16} className="shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-900/60 rounded-xl text-emerald-400 text-xs flex items-center gap-2 mb-4 font-semibold">
              <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Tab 1: Login Form */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-5 flex-1">
              {/* Role selector buttons */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">
                  Select Portal Gateway
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {[
                    { id: 'super_admin', label: 'HQ Admin', icon: ShieldCheck },
                    { id: 'branch_admin', label: 'Branch Admin', icon: ShieldCheck },
                    { id: 'teacher', label: 'Faculty', icon: UserCheck },
                    { id: 'student', label: 'Student', icon: User }
                  ].map((roleOpt) => {
                    const isSel = loginRole === roleOpt.id;
                    const Icon = roleOpt.icon;
                    return (
                      <button
                        key={roleOpt.id}
                        type="button"
                        onClick={() => {
                          setLoginRole(roleOpt.id as UserRole);
                          setErrorMsg('');
                        }}
                        className={`p-3 rounded-xl border text-xs flex flex-col items-center justify-center gap-1.5 transition-all ${
                          isSel 
                            ? 'bg-blue-600/10 border-blue-500/60 text-white' 
                            : 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        <Icon size={16} className={isSel ? 'text-blue-400 animate-pulse' : ''} />
                        <span className="font-semibold text-[11px] whitespace-nowrap">{roleOpt.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Email Address */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold flex justify-between">
                  <span>Email or Roll Number *</span>
                  <span className="text-[9px] text-slate-500 lowercase font-medium">Case sensitive</span>
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 text-slate-500" size={15} />
                  <input
                    type="text"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={
                      loginRole === 'student' 
                        ? 'e.g. aarav@pjrs.org or PJRS-2026-1001' 
                        : loginRole === 'super_admin'
                          ? 'e.g. hq@pjrs.org'
                          : loginRole === 'branch_admin'
                            ? 'e.g. branch@pjrs.org'
                            : 'e.g. suman.sharma@pjrs.org'
                    }
                    className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-100 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-medium"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">
                  Password *
                </label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-3 text-slate-500" size={15} />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-100 rounded-xl py-2.5 pl-9 pr-4 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all shadow-lg shadow-blue-600/15 flex items-center justify-center gap-1.5 mt-2"
              >
                <span>Authorize & Enter Portal</span>
                <LogIn size={14} />
              </button>
            </form>
          )}

          {/* Tab 2: Register Form */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 flex-1">
              
              {/* Account Type Toggle */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">
                  Account Type
                </label>
                <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800/60">
                  <button
                    type="button"
                    onClick={() => setRegRole('student')}
                    className={`py-2 px-3 text-xs font-bold rounded-lg transition-all ${
                      regRole === 'student' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Student Account
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegRole('teacher')}
                    className={`py-2 px-3 text-xs font-bold rounded-lg transition-all ${
                      regRole === 'teacher' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Teacher Profile
                  </button>
                </div>
              </div>

              {/* Common Name & Email Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder={regRole === 'student' ? 'e.g. Rahul Kumar' : 'e.g. Mr. S. K. Singh'}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="e.g. name@example.com"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Choose Password *</label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                {/* Campus Branch */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Assign Campus *</label>
                  <select
                    value={regBranch}
                    onChange={(e) => setRegBranch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    {branches.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* STUDENT ROLE FIELDS */}
              {regRole === 'student' && (
                <div className="space-y-3 pt-2 border-t border-slate-800/40">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Class *</label>
                      <select
                        value={regClass}
                        onChange={(e) => setRegClass(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        <option value="Class 9">Class 9</option>
                        <option value="Class 10">Class 10</option>
                        <option value="Class 11">Class 11</option>
                        <option value="Class 12">Class 12</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Section *</label>
                      <select
                        value={regSection}
                        onChange={(e) => setRegSection(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                      >
                        <option value="A">Section A</option>
                        <option value="B">Section B</option>
                        <option value="C">Section C</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Parent Name *</label>
                      <input
                        type="text"
                        required
                        value={regParentName}
                        onChange={(e) => setRegParentName(e.target.value)}
                        placeholder="Father or Mother"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Parent Phone *</label>
                      <input
                        type="text"
                        required
                        value={regParentPhone}
                        onChange={(e) => setRegParentPhone(e.target.value)}
                        placeholder="Contact number"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none font-mono"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Parent Email</label>
                      <input
                        type="email"
                        value={regParentEmail}
                        onChange={(e) => setRegParentEmail(e.target.value)}
                        placeholder="Optional"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TEACHER ROLE FIELDS */}
              {regRole === 'teacher' && (
                <div className="space-y-3 pt-2 border-t border-slate-800/40">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Subject Specialty *</label>
                      <input
                        type="text"
                        required
                        value={regSpecialty}
                        onChange={(e) => setRegSpecialty(e.target.value)}
                        placeholder="Mathematics, Physics, Chemistry..."
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Assigned Class-Section *</label>
                      <input
                        type="text"
                        required
                        value={regAssignedClass}
                        onChange={(e) => setRegAssignedClass(e.target.value)}
                        placeholder="e.g. Class 10-A"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Contact Phone *</label>
                      <input
                        type="text"
                        required
                        value={regPhone}
                        onChange={(e) => setRegPhone(e.target.value)}
                        placeholder="+91 XXXXX XXXXX"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none font-mono"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Highest Qualification *</label>
                      <input
                        type="text"
                        required
                        value={regQual}
                        onChange={(e) => setRegQual(e.target.value)}
                        placeholder="M.Sc Mathematics, B.Ed"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all shadow-lg shadow-blue-600/15 flex items-center justify-center gap-1.5 mt-2"
              >
                <span>Register & Log In</span>
                <ChevronRight size={14} />
              </button>
            </form>
          )}

          {/* Quick Demo Credentials Switcher */}
          <div className="mt-8 pt-6 border-t border-slate-800/60">
            <div className="flex items-center gap-2 mb-3.5">
              <Sparkles size={14} className="text-amber-400" />
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
                Quick Login Demo Accounts (Pre-loaded)
              </span>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleQuickLogin('super_admin')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 p-2 rounded-xl text-left transition-colors flex flex-col gap-0.5"
              >
                <div className="text-[10px] font-bold text-white flex items-center justify-between">
                  <span>HQ Admin</span>
                  <span className="bg-blue-900/40 text-blue-400 text-[8px] px-1 py-0.2 rounded font-mono uppercase font-black">HQ</span>
                </div>
                <span className="text-[9px] font-mono text-slate-500 truncate">hq@pjrs.org / hq123</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('branch_admin')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 p-2 rounded-xl text-left transition-colors flex flex-col gap-0.5"
              >
                <div className="text-[10px] font-bold text-white flex items-center justify-between">
                  <span>Branch Admin</span>
                  <span className="bg-cyan-900/40 text-cyan-400 text-[8px] px-1 py-0.2 rounded font-mono uppercase font-black">BR</span>
                </div>
                <span className="text-[9px] font-mono text-slate-500 truncate">branch@pjrs.org / branch123</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('teacher')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 p-2 rounded-xl text-left transition-colors flex flex-col gap-0.5"
              >
                <div className="text-[10px] font-bold text-white flex items-center justify-between">
                  <span>Class Teacher</span>
                  <span className="bg-indigo-900/40 text-indigo-400 text-[8px] px-1 py-0.2 rounded font-mono uppercase font-black">FAC</span>
                </div>
                <span className="text-[9px] font-mono text-slate-500 truncate">suman.sharma@pjrs.org / teacher123</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('student')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 p-2 rounded-xl text-left transition-colors flex flex-col gap-0.5"
              >
                <div className="text-[10px] font-bold text-white flex items-center justify-between">
                  <span>Student (10-A)</span>
                  <span className="bg-emerald-900/40 text-emerald-400 text-[8px] px-1 py-0.2 rounded font-mono uppercase font-black">PUP</span>
                </div>
                <span className="text-[9px] font-mono text-slate-500 truncate">aarav@pjrs.org / student123</span>
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
