import React, { useState } from 'react';
import { 
  DollarSign, 
  Search, 
  CreditCard, 
  Download, 
  FileText, 
  CheckCircle, 
  TrendingUp, 
  AlertCircle,
  X,
  User,
  Plus
} from 'lucide-react';
import { Student, FeeTransaction, Branch, BranchId } from '../types';

interface FinanceManagerProps {
  students: Student[];
  transactions: FeeTransaction[];
  branches: Branch[];
  selectedBranchId: BranchId;
  onAddTransaction: (newTx: FeeTransaction) => void;
  onUpdateStudentFees: (studentId: string, amountPaid: number) => void;
}

export default function FinanceManager({
  students,
  transactions,
  branches,
  selectedBranchId,
  onAddTransaction,
  onUpdateStudentFees
}: FinanceManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isCollectModalOpen, setIsCollectModalOpen] = useState(false);
  const [activeReceipt, setActiveReceipt] = useState<FeeTransaction | null>(null);

  // Fee collection form states
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [collectAmount, setCollectAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'Online' | 'Cheque' | 'UPI'>('UPI');

  // filter transactions
  const filteredTxs = transactions.filter(t => {
    const matchesBranch = selectedBranchId === 'all' ? true : t.branchId === selectedBranchId;
    const matchesSearch = t.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.receiptNo.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesBranch && matchesSearch;
  });

  // students with outstanding dues in the active branch
  const studentsWithDues = students.filter(s => {
    const matchesBranch = selectedBranchId === 'all' ? true : s.branchId === selectedBranchId;
    return matchesBranch && s.feesDue > 0;
  });

  const selectedStudentDetails = students.find(s => s.id === selectedStudentId);

  const handleCollectFeeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentId || !collectAmount) {
      alert('Please select a student and specify an amount.');
      return;
    }

    const amt = Number(collectAmount);
    if (amt <= 0) {
      alert('Amount must be positive.');
      return;
    }

    if (selectedStudentDetails && amt > selectedStudentDetails.feesDue) {
      alert(`Amount cannot exceed the pending balance of ₹${selectedStudentDetails.feesDue.toLocaleString('en-IN')}`);
      return;
    }

    const receiptNo = `REC-2026-${Math.floor(10000 + Math.random() * 90000)}`;
    const txId = `tx_${Date.now()}`;

    const newTx: FeeTransaction = {
      id: txId,
      studentId: selectedStudentId,
      studentName: selectedStudentDetails!.name,
      rollNumber: selectedStudentDetails!.rollNumber,
      branchId: selectedStudentDetails!.branchId,
      amount: amt,
      date: new Date().toISOString().split('T')[0],
      paymentMode,
      status: 'Paid',
      receiptNo
    };

    onAddTransaction(newTx);
    onUpdateStudentFees(selectedStudentId, amt);
    
    // Reset Form
    setIsCollectModalOpen(false);
    setSelectedStudentId('');
    setCollectAmount('');
    
    // Automatically display the invoice receipt for a high-quality feedback loop
    setActiveReceipt(newTx);
  };

  // Consolidated Financial Statistics for active branch
  const activeStudents = selectedBranchId === 'all' ? students : students.filter(s => s.branchId === selectedBranchId);
  const totalExpected = activeStudents.reduce((sum, s) => sum + s.feesTotal, 0);
  const totalCollected = activeStudents.reduce((sum, s) => sum + s.feesPaid, 0);
  const totalDue = activeStudents.reduce((sum, s) => sum + s.feesDue, 0);

  return (
    <div className="p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header and Control Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans text-slate-900">Finance & Fee Accounts Ledger</h2>
          <p className="text-xs text-slate-500 mt-1">
            Reconcile multi-campus tuition deposits, verify electronic UPI/cash receipts, and generate invoices.
          </p>
        </div>
        <button
          onClick={() => setIsCollectModalOpen(true)}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-xl text-xs shadow-md shadow-emerald-500/10 transition-all duration-150 self-start md:self-auto"
        >
          <Plus size={16} />
          Record Fee Payment
        </button>
      </div>

      {/* Finance KPI Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/40 border border-emerald-100 p-5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-700 font-bold">Total Fees Realized</span>
            <h3 className="text-2xl font-bold font-sans text-emerald-800 mt-1">₹{totalCollected.toLocaleString('en-IN')}</h3>
            <p className="text-[10px] text-emerald-600 font-medium mt-1">
              {totalExpected > 0 ? Math.round((totalCollected / totalExpected) * 100) : 0}% of annual target paid
            </p>
          </div>
          <div className="p-3.5 bg-emerald-500 text-white rounded-2xl shadow-md shadow-emerald-500/10">
            <TrendingUp size={20} />
          </div>
        </div>

        <div className="bg-gradient-to-br from-rose-50 to-rose-100/40 border border-rose-100 p-5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-rose-700 font-bold">Outstanding Deficit</span>
            <h3 className="text-2xl font-bold font-sans text-rose-800 mt-1">₹{totalDue.toLocaleString('en-IN')}</h3>
            <p className="text-[10px] text-rose-600 font-medium mt-1">Requires active administrative notice</p>
          </div>
          <div className="p-3.5 bg-rose-500 text-white rounded-2xl shadow-md shadow-rose-500/10">
            <AlertCircle size={20} />
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-blue-100/40 border border-blue-100 p-5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-blue-700 font-bold">Consolidated Expected Revenue</span>
            <h3 className="text-2xl font-bold font-sans text-blue-800 mt-1">₹{totalExpected.toLocaleString('en-IN')}</h3>
            <p className="text-[10px] text-blue-600 font-medium mt-1">Tuition, exams, labs, and sports structures</p>
          </div>
          <div className="p-3.5 bg-blue-500 text-white rounded-2xl shadow-md shadow-blue-500/10">
            <DollarSign size={20} />
          </div>
        </div>
      </div>

      {/* Transactions and Search Panel */}
      <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h4 className="text-sm font-bold text-slate-900">Recent Deposit Records</h4>
            <p className="text-[11px] text-slate-500">Searchable ledger of cleared deposits and tuition settlements.</p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-2.5 text-slate-400" size={14} />
            <input
              type="text"
              placeholder="Search student, Roll No, Receipt No..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg py-1.5 pl-9 pr-4 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-100">
                <th className="p-4 font-semibold">Receipt Number</th>
                <th className="p-4 font-semibold">Student Name / Roll</th>
                <th className="p-4 font-semibold">Campus Branch</th>
                <th className="p-4 font-semibold">Date of Payment</th>
                <th className="p-4 font-semibold">Method</th>
                <th className="p-4 font-semibold">Status</th>
                <th className="p-4 font-semibold text-right">Deposited</th>
                <th className="p-4 font-semibold text-right">Invoices</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredTxs.length > 0 ? (
                filteredTxs.map((tx) => {
                  const branch = branches.find(b => b.id === tx.branchId);
                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 font-mono font-bold text-blue-600">{tx.receiptNo}</td>
                      <td className="p-4">
                        <div className="font-bold text-slate-900">{tx.studentName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{tx.rollNumber}</div>
                      </td>
                      <td className="p-4">
                        <span className="font-semibold text-slate-700">{branch?.name.split(' (')[0]}</span>
                      </td>
                      <td className="p-4 text-slate-500 font-mono">{tx.date}</td>
                      <td className="p-4">
                        <span className="font-mono text-[10px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded border border-slate-200">
                          {tx.paymentMode}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="text-[10px] font-mono bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded font-bold">
                          CLEARED
                        </span>
                      </td>
                      <td className="p-4 text-right font-mono font-bold text-slate-900">
                        ₹{tx.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => setActiveReceipt(tx)}
                          className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg hover:text-slate-950 transition-colors inline-flex items-center gap-1"
                        >
                          <FileText size={14} />
                          <span className="text-[10px] font-semibold">Receipt</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No transactions found matching search filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Collect Fee Modal */}
      {isCollectModalOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-mono uppercase tracking-wider text-slate-400">Tuition Settlement</h3>
                <h2 className="text-base font-bold font-sans mt-0.5">Record Student Fee Collection</h2>
              </div>
              <button onClick={() => setIsCollectModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleCollectFeeSubmit} className="p-6 space-y-4">
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Select Student (With Dues) *</label>
                <select
                  required
                  value={selectedStudentId}
                  onChange={(e) => {
                    setSelectedStudentId(e.target.value);
                    const std = students.find(s => s.id === e.target.value);
                    if (std) setCollectAmount(String(std.feesDue));
                  }}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                >
                  <option value="">-- Choose student --</option>
                  {studentsWithDues.map((s) => {
                    const b = branches.find(br => br.id === s.branchId);
                    return (
                      <option key={s.id} value={s.id}>
                        👤 {s.name} ({s.class} | Due: ₹{s.feesDue.toLocaleString('en-IN')} | Campus: {b?.code})
                      </option>
                    );
                  })}
                </select>
              </div>

              {selectedStudentDetails && (
                <div className="p-4 bg-slate-50 rounded-xl space-y-2 border border-slate-100 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span>Parent:</span>
                    <span className="font-bold text-slate-900">{selectedStudentDetails.parentName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Annual Fee:</span>
                    <span className="font-mono text-slate-800">₹{selectedStudentDetails.feesTotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Paid to Date:</span>
                    <span className="font-mono text-slate-800">₹{selectedStudentDetails.feesPaid.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-2 font-bold text-slate-900">
                    <span>Outstanding Due:</span>
                    <span className="text-rose-600 font-mono">₹{selectedStudentDetails.feesDue.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Amount to Collect (INR) *</label>
                  <input
                    type="number"
                    required
                    value={collectAmount}
                    onChange={(e) => setCollectAmount(e.target.value)}
                    placeholder="Enter amount"
                    max={selectedStudentDetails?.feesDue || undefined}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Payment Method *</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="UPI">UPI (GPay / PhonePe)</option>
                    <option value="Online">NetBanking / Card</option>
                    <option value="Cash">Cash Handover</option>
                    <option value="Cheque">Bank Cheque</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCollectModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg text-xs font-semibold shadow-md shadow-emerald-500/10 transition-colors"
                >
                  Verify and Deposit Fee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Receipt PDF popup */}
      {activeReceipt && (
        <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            {/* Printable Receipt Frame */}
            <div className="p-8 space-y-6">
              {/* Header */}
              <div className="flex justify-between items-start border-b border-slate-100 pb-5">
                <div>
                  <h1 className="text-sm font-black tracking-tight text-slate-900 uppercase">PJRS Group of Schools</h1>
                  <p className="text-[10px] font-mono text-slate-400">PJRS.ORG Official Fee Invoice</p>
                  <p className="text-[10px] text-slate-500 mt-2 max-w-[180px]">
                    {branches.find(b => b.id === activeReceipt.branchId)?.address || 'New Delhi HQ'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded font-mono font-bold">
                    PAID
                  </span>
                  <p className="text-[10px] font-mono text-slate-400 mt-2">Receipt No:</p>
                  <p className="text-xs font-mono font-bold text-slate-900">{activeReceipt.receiptNo}</p>
                </div>
              </div>

              {/* Body Details */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Deposit Settlement Details</h4>
                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Student Name:</span>
                    <span className="font-bold text-slate-900">{activeReceipt.studentName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Roll Number:</span>
                    <span className="font-mono font-bold text-slate-800">{activeReceipt.rollNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Deposit Date:</span>
                    <span className="font-mono text-slate-800">{activeReceipt.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Payment Channel:</span>
                    <span className="font-bold text-slate-800">{activeReceipt.paymentMode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Transaction Status:</span>
                    <span className="text-emerald-600 font-semibold">SUCCESS / DEPOSITED</span>
                  </div>
                </div>
              </div>

              {/* Total Card */}
              <div className="bg-slate-900 text-white p-4 rounded-xl flex justify-between items-center font-mono">
                <div>
                  <span className="text-[10px] text-slate-400">TOTAL PAID</span>
                  <h3 className="text-lg font-black mt-0.5">INR ₹{activeReceipt.amount.toLocaleString('en-IN')}</h3>
                </div>
                <CreditCard size={24} className="text-slate-400" />
              </div>

              {/* Verification watermark */}
              <div className="text-center pt-2 text-[10px] text-slate-400 leading-relaxed font-mono">
                This is a computer-generated official payment confirmation generated on behalf of PJRS School Accounts Department. No physical signature is required.
              </div>
            </div>

            {/* Actions Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex justify-between gap-3">
              <button
                onClick={() => alert('Download simulated. PDF is downloaded to local storage.')}
                className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
              >
                <Download size={14} /> Download PDF
              </button>
              <button
                onClick={() => setActiveReceipt(null)}
                className="bg-slate-900 hover:bg-slate-800 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
              >
                Close Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
