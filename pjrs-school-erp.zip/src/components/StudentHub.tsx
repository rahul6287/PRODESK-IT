import React, { useState, useEffect } from 'react';
import { 
  User, 
  CreditCard, 
  ShoppingBag, 
  BookOpen, 
  Send, 
  UploadCloud, 
  CheckCircle, 
  FileText, 
  Download, 
  Sparkles, 
  Info, 
  MessageSquare,
  AlertCircle,
  FileCheck2,
  Calendar,
  Clock,
  ExternalLink
} from 'lucide-react';
import { Student, Branch, FeeTransaction, Staff } from '../types';

interface StudentHubProps {
  students: Student[];
  branches: Branch[];
  transactions: FeeTransaction[];
  staffList: Staff[];
  onAddTransaction: (newTx: FeeTransaction) => void;
  onUpdateStudentFees: (studentId: string, amountPaid: number) => void;
  onPurchaseStoreItem?: (studentId: string, itemName: string, amount: number) => void;
  activeStudentTab: string;
  setActiveStudentTab: (tab: string) => void;
  loggedInStudentId?: string;
}

interface ChatMessage {
  id: string;
  sender: 'student' | 'teacher';
  text: string;
  timestamp: string;
}

interface Assignment {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  description: string;
  maxMarks: number;
}

const STATIC_ASSIGNMENTS: Assignment[] = [
  {
    id: 'asg_1',
    title: 'Algebra Quadratic Equations Exercises',
    subject: 'Mathematics',
    dueDate: '2026-07-20',
    description: 'Solve exercises 4.1 to 4.4 from your Mathematics textbook. Show all steps clearly in your notebook or scan and upload a single PDF file.',
    maxMarks: 50
  },
  {
    id: 'asg_2',
    title: 'Physics Refraction and Lenses Lab Report',
    subject: 'Science',
    dueDate: '2026-07-25',
    description: 'Complete the lab observation table for light traveling through glass prisms. Calculate refractive index and draw the ray diagrams.',
    maxMarks: 30
  },
  {
    id: 'asg_3',
    title: 'English Narrative Essay on Character Building',
    subject: 'English',
    dueDate: '2026-07-18',
    description: 'Write an essay (350-500 words) on: "The role of empathy in modern leadership". Highlight personal experiences or references from novels read.',
    maxMarks: 20
  }
];

const STORE_ITEMS = [
  { id: 'item_bag', name: 'PJRS Premium Orthopedic School Bag', price: 1200, category: 'Bags', icon: ShoppingBag, color: 'text-blue-600 bg-blue-50 border-blue-100' },
  { id: 'item_tie', name: 'PJRS Crest House Color Tie', price: 250, category: 'Uniform', icon: ShoppingBag, color: 'text-rose-600 bg-rose-50 border-rose-100' },
  { id: 'item_diary', name: 'PJRS Smart Academic Diary & Planner 2026', price: 180, category: 'Stationery', icon: FileText, color: 'text-amber-600 bg-amber-50 border-amber-100' },
  { id: 'item_socks', name: 'Cushioned Socks Pack (Set of 3 Pairs)', price: 300, category: 'Uniform', icon: ShoppingBag, color: 'text-emerald-600 bg-emerald-50 border-emerald-100' },
  { id: 'item_labcoat', name: 'Anti-Static White Chemistry Lab Coat', price: 450, category: 'Lab Wear', icon: ShoppingBag, color: 'text-violet-600 bg-violet-50 border-violet-100' },
  { id: 'item_blazer', name: 'Winter Warm Woolen Crest Blazer', price: 1850, category: 'Uniform', icon: ShoppingBag, color: 'text-indigo-600 bg-indigo-50 border-indigo-100' },
];

export default function StudentHub({
  students,
  branches,
  transactions,
  staffList,
  onAddTransaction,
  onUpdateStudentFees,
  onPurchaseStoreItem,
  activeStudentTab,
  setActiveStudentTab,
  loggedInStudentId
}: StudentHubProps) {
  // Select which student is logged in
  const [selectedStudentId, setSelectedStudentId] = useState<string>(loggedInStudentId || students[0]?.id || 'std_01');

  // Keep state in sync with loggedInStudentId
  useEffect(() => {
    if (loggedInStudentId) {
      setSelectedStudentId(loggedInStudentId);
    }
  }, [loggedInStudentId]);

  const currentStudent = students.find(s => s.id === selectedStudentId) || students[0];

  // UI Local States
  const [payAmount, setPayAmount] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<'UPI' | 'Online' | 'Card'>('UPI');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>('');
  const [typedMessage, setTypedMessage] = useState<string>('');
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [lastReceipt, setLastReceipt] = useState<string>('');

  // Local storage structures for Chats and Assignments to persist simulated interactions
  const [chats, setChats] = useState<Record<string, ChatMessage[]>>(() => {
    const saved = localStorage.getItem('pjrs_erp_student_chats');
    return saved ? JSON.parse(saved) : {
      'std_01_staff_01': [
        { id: 'm1', sender: 'teacher', text: 'Hi Aarav, please make sure to submit your Math algebra assignments by Friday.', timestamp: '10:00 AM' },
        { id: 'm2', sender: 'student', text: 'Sure Maam, I am working on it and will upload it today.', timestamp: '10:15 AM' }
      ]
    };
  });

  const [submissions, setSubmissions] = useState<Record<string, { fileName: string; date: string; status: string }>>(() => {
    const saved = localStorage.getItem('pjrs_erp_submissions');
    return saved ? JSON.parse(saved) : {};
  });

  // Save states
  useEffect(() => {
    localStorage.setItem('pjrs_erp_student_chats', JSON.stringify(chats));
  }, [chats]);

  useEffect(() => {
    localStorage.setItem('pjrs_erp_submissions', JSON.stringify(submissions));
  }, [submissions]);

  // Synchronize chats from localStorage when the chat tab is opened
  useEffect(() => {
    if (activeStudentTab === 'chat') {
      const saved = localStorage.getItem('pjrs_erp_student_chats');
      if (saved) {
        try {
          setChats(JSON.parse(saved));
        } catch (e) {
          console.error(e);
        }
      }
    }
  }, [activeStudentTab, selectedStudentId, selectedTeacherId]);

  // Handle active student change
  useEffect(() => {
    // Select default teacher who teaches this branch/class if possible
    const matchingTeachers = staffList.filter(t => t.branchId === currentStudent?.branchId && t.role === 'Teacher');
    if (matchingTeachers.length > 0) {
      setSelectedTeacherId(matchingTeachers[0].id);
    } else if (staffList.length > 0) {
      setSelectedTeacherId(staffList[0].id);
    }
  }, [selectedStudentId, staffList, currentStudent]);

  if (!currentStudent) {
    return <div className="p-8 text-center text-slate-500">No students found.</div>;
  }

  const activeBranch = branches.find(b => b.id === currentStudent.branchId);

  // Grade Calculations
  const gradesArray = Object.entries(currentStudent.grades);
  const totalGradesScore = gradesArray.reduce((sum, [_, val]) => sum + (Number(val) || 0), 0);
  const avgGrade = gradesArray.length > 0 ? (totalGradesScore / gradesArray.length).toFixed(1) : 'N/A';
  
  // Calculate GPA out of 10
  const gpa = gradesArray.length > 0 ? ((Number(avgGrade) / 10)).toFixed(2) : 'N/A';

  // Division logic
  let division = 'Fail';
  if (gradesArray.length > 0) {
    const avg = Number(avgGrade);
    if (avg >= 75) division = 'Distinction (First Class with Honors)';
    else if (avg >= 60) division = 'First Division';
    else if (avg >= 50) division = 'Second Division';
    else if (avg >= 33) division = 'Third Division (Pass)';
    else division = 'Essential Repeat';
  }

  // Handle pay tuition
  const handlePayTuition = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = Number(payAmount);
    if (!amountNum || amountNum <= 0) {
      alert('Please enter a valid amount.');
      return;
    }
    if (amountNum > currentStudent.feesDue) {
      alert(`Amount entered is higher than remaining due fees of ₹${currentStudent.feesDue.toLocaleString('en-IN')}`);
      return;
    }

    const receiptNo = `REC-${Math.floor(10000 + Math.random() * 90000)}`;
    const txId = `tx_${Date.now()}`;

    const newTx: FeeTransaction = {
      id: txId,
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      rollNumber: currentStudent.rollNumber,
      branchId: currentStudent.branchId,
      amount: amountNum,
      date: new Date().toISOString().split('T')[0],
      paymentMode: paymentMode === 'Card' ? 'Cheque' : (paymentMode === 'UPI' ? 'UPI' : 'Online'),
      status: 'Paid',
      receiptNo
    };

    onAddTransaction(newTx);
    onUpdateStudentFees(currentStudent.id, amountNum);
    
    setLastReceipt(receiptNo);
    setPaymentSuccess(true);
    setPayAmount('');
    setTimeout(() => setPaymentSuccess(false), 5000);
  };

  // Handle buy store item
  const handleBuyStoreItem = (itemName: string, price: number) => {
    const confirmBuy = window.confirm(`Confirm payment of ₹${price} for "${itemName}"? Amount will be debited instantly via mock gateway and recorded.`);
    if (!confirmBuy) return;

    const receiptNo = `REC-STR-${Math.floor(10000 + Math.random() * 90000)}`;
    const txId = `tx_store_${Date.now()}`;

    // Add transaction to central ledger
    const newTx: FeeTransaction = {
      id: txId,
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      rollNumber: currentStudent.rollNumber,
      branchId: currentStudent.branchId,
      amount: price,
      date: new Date().toISOString().split('T')[0],
      paymentMode: 'UPI',
      status: 'Paid',
      receiptNo
    };

    onAddTransaction(newTx);

    if (onPurchaseStoreItem) {
      onPurchaseStoreItem(currentStudent.id, itemName, price);
    } else {
      // fallback if not provided: register payment through onUpdateStudentFees or alert success
      onUpdateStudentFees(currentStudent.id, 0); // trigger re-render
    }

    alert(`🛍️ Purchase Successful!\n\nReceipt: ${receiptNo}\nItem: ${itemName}\nAmount Paid: ₹${price}\n\nItem will be delivered to Class ${currentStudent.class}-${currentStudent.section} by the branch dispatcher.`);
  };

  // Handle Send Chat
  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMessage.trim() || !selectedTeacherId) return;

    const chatKey = `${currentStudent.id}_${selectedTeacherId}`;
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'student',
      text: typedMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedHistory = [...(chats[chatKey] || []), newMsg];
    setChats(prev => ({
      ...prev,
      [chatKey]: updatedHistory
    }));

    setTypedMessage('');

    // Trigger simulated teacher response after 1.5s
    const teacher = staffList.find(st => st.id === selectedTeacherId);
    setTimeout(() => {
      const teacherResponses = [
        `Thanks for the update, ${currentStudent.name}. I have marked your message. Keep up the good work.`,
        `Hello ${currentStudent.name}. Yes, I saw your submission. Please revise the third question and double check.`,
        `Perfect. If you have any difficulties, we can discuss them in the doubt clearing session tomorrow.`,
        `I will update your mid-term sheet grades in the system shortly. Please keep studying.`,
        `Please ensure you maintain at least 85% attendance to qualify for the final exams.`
      ];
      const randomReply = teacherResponses[Math.floor(Math.random() * teacherResponses.length)];
      
      const teacherMsg: ChatMessage = {
        id: `msg_reply_${Date.now()}`,
        sender: 'teacher',
        text: randomReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setChats(prev => ({
        ...prev,
        [chatKey]: [...(prev[chatKey] || []), teacherMsg]
      }));
    }, 1500);
  };

  // Handle Mock Assignment File Upload
  const handleMockUpload = (assignmentId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setSubmissions(prev => ({
      ...prev,
      [`${currentStudent.id}_${assignmentId}`]: {
        fileName: file.name,
        date: new Date().toISOString().split('T')[0],
        status: 'Submitted'
      }
    }));

    alert(`📄 Document "${file.name}" uploaded successfully for assignment!\nStatus changed to: Submitted.`);
  };

  // Filter Transactions for this student
  const studentTx = transactions.filter(t => t.studentId === currentStudent.id);
  const currentChatKey = `${currentStudent.id}_${selectedTeacherId}`;
  const activeChatHistory = chats[currentChatKey] || [];

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Student Portal Selector & Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white border border-slate-100 p-6 rounded-2xl shadow-sm gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-emerald-50 text-emerald-600 text-[10px] uppercase font-mono px-2 py-0.5 rounded border border-emerald-100 font-bold tracking-wider">
              Student & Parent Portal
            </span>
            <span className="text-slate-400 text-xs font-mono">• Session: 2026-2027</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 font-sans">Student Workspace</h2>
          <p className="text-xs text-slate-500 mt-1">
            Access personalized marksheets, pay dynamic fees, buy from school utilities, and chat with teachers.
          </p>
        </div>

        {/* Dynamic Logged In Student Selector */}
        <div className="flex items-center gap-3 bg-slate-50 border border-slate-100 p-3 rounded-xl min-w-[280px]">
          <div className="bg-blue-100 text-blue-600 p-2 rounded-lg">
            <User size={18} />
          </div>
          <div className="flex-1">
            <label className="text-[9px] uppercase font-mono font-bold text-slate-400 block">
              {loggedInStudentId ? 'Active Logged In Student' : 'Select Active Student Profile'}
            </label>
            {loggedInStudentId ? (
              <span className="text-xs font-bold text-slate-800 block mt-0.5 truncate">
                {currentStudent.name} ({currentStudent.class}-{currentStudent.section})
              </span>
            ) : (
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="bg-transparent border-none text-xs font-bold text-slate-800 focus:outline-none w-full p-0 cursor-pointer"
              >
                {students.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.class}-{s.section})</option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex border-b border-slate-200 gap-1 overflow-x-auto pb-px">
        {[
          { id: 'dashboard', label: 'My Academic Hub', icon: BookOpen },
          { id: 'grades', label: 'My Report Card / Marks', icon: FileCheck2 },
          { id: 'fees', label: 'Fees & Store Payment', icon: CreditCard },
          { id: 'assignments', label: 'Homework Uploads', icon: UploadCloud },
          { id: 'chat', label: 'Chat with Faculty', icon: MessageSquare },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeStudentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveStudentTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
                isActive 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* RENDER ACTIVE STUDENT TAB SCREEN */}

      {/* STUDENT DASHBOARD OVERVIEW */}
      {activeStudentTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Welcome Alert & Attendance */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 bg-gradient-to-br from-blue-900 to-blue-950 text-white rounded-2xl p-6 flex flex-col justify-between border border-blue-800 shadow-sm relative overflow-hidden">
              <div className="absolute right-0 bottom-0 opacity-10 translate-y-6 translate-x-6 text-white">
                <BookOpen size={200} />
              </div>
              <div className="z-10">
                <div className="flex items-center gap-2">
                  <Sparkles size={16} className="text-amber-300" />
                  <span className="text-[10px] font-mono tracking-wider text-blue-300 uppercase font-semibold">Welcome back, Scholar</span>
                </div>
                <h3 className="text-2xl font-black mt-2 font-sans text-white">{currentStudent.name}</h3>
                <p className="text-xs text-blue-100/90 mt-1 max-w-md">
                  Class: <strong>{currentStudent.class} (Section {currentStudent.section})</strong> | Roll No: <strong>{currentStudent.rollNumber}</strong>
                </p>
                <div className="mt-3 text-[11px] bg-blue-800/40 border border-blue-700/50 px-3 py-1.5 rounded-lg inline-block text-blue-200">
                  📍 Campus Branch: <strong>{activeBranch?.name}</strong>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-blue-800/60 flex flex-wrap justify-between items-center text-xs text-blue-100 z-10 gap-3">
                <div className="flex gap-4 font-mono text-[11px]">
                  <span>Attendance: <strong className="text-emerald-300">{currentStudent.attendanceRate}%</strong></span>
                  <span>Exam Avg: <strong className="text-amber-300">{avgGrade}%</strong></span>
                </div>
                <button 
                  onClick={() => setActiveStudentTab('grades')}
                  className="bg-white/10 hover:bg-white/20 text-white font-semibold px-3 py-1.5 rounded-lg text-[10px] transition-colors border border-white/10"
                >
                  View Full Marksheet
                </button>
              </div>
            </div>

            {/* Quick Balance Status */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-3">
                  <span className="text-[10px] uppercase font-mono text-slate-400 font-bold">Outstanding Dues</span>
                  <span className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                    <CreditCard size={16} />
                  </span>
                </div>
                <h4 className="text-2xl font-black text-slate-900 mt-1">₹{currentStudent.feesDue.toLocaleString('en-IN')}</h4>
                <p className="text-[11px] text-slate-500 mt-1">Out of tuition fees total: ₹{currentStudent.feesTotal.toLocaleString('en-IN')}</p>
              </div>

              <div className="mt-6">
                {currentStudent.feesDue > 0 ? (
                  <button
                    onClick={() => setActiveStudentTab('fees')}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-xl text-xs shadow-md shadow-blue-500/10 transition-all flex items-center justify-center gap-1.5"
                  >
                    Pay Tuition Outstanding
                  </button>
                ) : (
                  <div className="bg-emerald-50 text-emerald-700 border border-emerald-100 px-3 py-2.5 rounded-xl text-center text-[11px] font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle size={14} /> Tuition Fees Fully Cleared!
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Timetable / Quick Notifications */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
              <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold mb-4">Class Weekly Schedule</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl text-xs">
                  <div className="w-16 font-mono text-slate-500 font-bold">MON • 08:30</div>
                  <div className="font-bold text-slate-900">Mathematics</div>
                  <div className="text-[11px] text-slate-500 ml-auto flex items-center gap-1">
                    <span>Mrs. Suman Sharma</span>
                    <span className="bg-slate-200 px-1.5 py-0.5 rounded text-[9px] font-mono">RM 201</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl text-xs">
                  <div className="w-16 font-mono text-slate-500 font-bold">MON • 09:25</div>
                  <div className="font-bold text-slate-900">Science (Physics)</div>
                  <div className="text-[11px] text-slate-500 ml-auto flex items-center gap-1">
                    <span>Mr. Anil Kapoor</span>
                    <span className="bg-slate-200 px-1.5 py-0.5 rounded text-[9px] font-mono">LAB B</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl text-xs">
                  <div className="w-16 font-mono text-slate-500 font-bold">MON • 10:30</div>
                  <div className="font-bold text-slate-900">English Literature</div>
                  <div className="text-[11px] text-slate-500 ml-auto flex items-center gap-1">
                    <span>Mrs. Anjali Roy</span>
                    <span className="bg-slate-200 px-1.5 py-0.5 rounded text-[9px] font-mono">RM 201</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold mb-4">Pending Tasks</h4>
                <div className="space-y-3">
                  <div className="flex items-start gap-2.5">
                    <input type="checkbox" defaultChecked={false} className="mt-1 rounded text-blue-600 focus:ring-blue-500" />
                    <div>
                      <div className="text-xs font-bold text-slate-800">Submit Algebra Assignment</div>
                      <p className="text-[10px] text-slate-400 font-mono">Due: 2026-07-20</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <input type="checkbox" defaultChecked={false} className="mt-1 rounded text-blue-600 focus:ring-blue-500" />
                    <div>
                      <div className="text-xs font-bold text-slate-800">Prepare for Physics Lab</div>
                      <p className="text-[10px] text-slate-400 font-mono">Due: 2026-07-25</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-50 text-[10px] text-slate-500 mt-4 leading-relaxed">
                📢 Please notify teachers immediately if any attendance metrics appear incorrect.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STUDENT MARKSHEET / REPORT CARD */}
      {activeStudentTab === 'grades' && (
        <div className="bg-white border border-slate-100 rounded-2xl p-8 shadow-sm max-w-3xl mx-auto space-y-6">
          {/* Print Roster Header */}
          <div className="border-4 border-double border-slate-300 p-6 rounded-xl space-y-6 relative">
            
            {/* Watermark Crest */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]">
              <BookOpen size={300} />
            </div>

            {/* School Header */}
            <div className="text-center space-y-1 pb-4 border-b border-slate-200">
              <h3 className="text-lg font-black font-sans tracking-tight text-slate-900">PJRS GROUP OF SCHOOLS</h3>
              <p className="text-[10px] uppercase font-mono tracking-widest text-slate-500">Academic Evaluation Directorate • Central Ledger</p>
              <p className="text-[11px] font-serif text-slate-600 font-medium italic">{activeBranch?.name}</p>
              <p className="text-[10px] font-mono text-slate-400">{activeBranch?.address}</p>
            </div>

            {/* Student Metadata Card */}
            <div className="grid grid-cols-2 gap-4 text-xs font-mono bg-slate-50 p-4 rounded-lg border border-slate-100">
              <div className="space-y-1">
                <div>Student Name: <strong className="text-slate-900">{currentStudent.name}</strong></div>
                <div>Class-Section: <strong className="text-slate-900">{currentStudent.class}-{currentStudent.section}</strong></div>
                <div>Roll Number: <strong className="text-slate-900">{currentStudent.rollNumber}</strong></div>
              </div>
              <div className="space-y-1">
                <div>Exam Session: <strong className="text-slate-900">Mid-Term 2026</strong></div>
                <div>Attendance Rate: <strong className="text-emerald-600">{currentStudent.attendanceRate}%</strong></div>
                <div>Status: <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.5 rounded">PASSED</span></div>
              </div>
            </div>

            {/* Grades Table */}
            <div className="space-y-1">
              <div className="grid grid-cols-12 bg-slate-800 text-white font-mono text-[10px] uppercase font-bold p-2.5 rounded-t-lg">
                <span className="col-span-5">Academic Subject</span>
                <span className="col-span-2 text-center">Max Marks</span>
                <span className="col-span-2 text-center">Min Pass</span>
                <span className="col-span-3 text-right">Marks Scored</span>
              </div>

              {gradesArray.map(([subject, marks]) => {
                const score = Number(marks) || 0;
                const isFailed = score < 33;
                return (
                  <div key={subject} className="grid grid-cols-12 text-xs p-2.5 border-b border-slate-100 font-medium items-center">
                    <span className="col-span-5 font-bold text-slate-800">{subject}</span>
                    <span className="col-span-2 text-center font-mono text-slate-500">100</span>
                    <span className="col-span-2 text-center font-mono text-slate-500">33</span>
                    <span className={`col-span-3 text-right font-mono font-black ${isFailed ? 'text-red-500' : 'text-slate-900'}`}>
                      {score} / 100
                    </span>
                  </div>
                );
              })}

              <div className="grid grid-cols-12 bg-slate-50 text-xs p-3 font-bold border-t border-slate-200">
                <span className="col-span-5 text-slate-700">AGGREGATE CONSOLIDATION</span>
                <span className="col-span-2 text-center font-mono text-slate-500">500</span>
                <span className="col-span-2 text-center font-mono text-slate-500">-</span>
                <span className="col-span-3 text-right font-mono font-black text-blue-700 text-sm">
                  {totalGradesScore} / 500
                </span>
              </div>
            </div>

            {/* GPA summary boxes */}
            <div className="grid grid-cols-3 gap-3 text-center pt-2">
              <div className="p-3 bg-blue-50/50 border border-blue-100 rounded-lg">
                <div className="text-[10px] uppercase font-mono text-slate-400 font-bold">GPA (Average)</div>
                <div className="text-lg font-black text-blue-700 font-mono mt-0.5">{gpa} / 10</div>
              </div>
              <div className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-lg">
                <div className="text-[10px] uppercase font-mono text-slate-400 font-bold">Average Percentage</div>
                <div className="text-lg font-black text-emerald-700 font-mono mt-0.5">{avgGrade}%</div>
              </div>
              <div className="p-3 bg-violet-50/50 border border-violet-100 rounded-lg col-span-1">
                <div className="text-[10px] uppercase font-mono text-slate-400 font-bold">Board Classification</div>
                <div className="text-xs font-bold text-slate-700 mt-2 truncate">{division}</div>
              </div>
            </div>

            {/* Signatures */}
            <div className="pt-8 flex justify-between text-[10px] font-mono text-slate-400">
              <div className="text-center w-36">
                <div className="border-b border-slate-300 pb-1 font-serif text-slate-600 italic">Mrs. Suman Sharma</div>
                <div className="mt-1">Class Evaluator</div>
              </div>
              <div className="text-center w-36">
                <div className="border-b border-slate-300 pb-1 font-serif text-slate-600 italic">Dr. R. Chandra</div>
                <div className="mt-1">Director/Principal</div>
              </div>
            </div>
          </div>

          {/* Download Simulation Actions */}
          <div className="flex justify-between items-center bg-slate-50 p-4 rounded-xl border border-slate-100 text-xs">
            <span className="text-slate-500 font-mono flex items-center gap-1">
              <Info size={14} className="text-blue-500" /> Digital Report Card encrypted under ISO Ledger.
            </span>
            <button
              onClick={() => {
                alert('🖨️ Initializing Printer Spooler...\n\nDigital Document compiled successfully. Printing standard class report sheets.');
                window.print();
              }}
              className="bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2 px-4 rounded-lg transition-colors flex items-center gap-2"
            >
              <Download size={14} /> Print Report Card
            </button>
          </div>
        </div>
      )}

      {/* FEES AND SCHOOL STORE */}
      {activeStudentTab === 'fees' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Tuition Fee Payment */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
              <h3 className="text-sm font-mono uppercase tracking-wider text-slate-400 font-bold mb-4">Tuition Fee Clearance</h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                    <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase">Total Tuition</span>
                    <strong className="text-slate-800 text-base font-mono">₹{currentStudent.feesTotal.toLocaleString('en-IN')}</strong>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                    <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase">Paid Ledger</span>
                    <strong className="text-emerald-600 text-base font-mono">₹{currentStudent.feesPaid.toLocaleString('en-IN')}</strong>
                  </div>
                </div>

                <div className="p-4 bg-rose-50/50 border border-rose-100 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-rose-500 uppercase font-mono font-bold">Outstanding Remaining Due</span>
                    <h4 className="text-xl font-mono font-black text-rose-600">₹{currentStudent.feesDue.toLocaleString('en-IN')}</h4>
                  </div>
                  <span className="text-[10px] bg-rose-100 text-rose-700 px-2.5 py-1 rounded-full font-mono font-bold uppercase tracking-wider">
                    DEFAULTER DUES
                  </span>
                </div>

                {currentStudent.feesDue > 0 ? (
                  <form onSubmit={handlePayTuition} className="space-y-4 pt-2">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Enter Payment Amount (₹)</label>
                      <input
                        type="number"
                        required
                        value={payAmount}
                        onChange={(e) => setPayAmount(e.target.value)}
                        placeholder="e.g. 5000"
                        max={currentStudent.feesDue}
                        min="1"
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-lg p-2.5 text-xs font-bold focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Select Gateway Mode</label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'UPI', label: '⚡ UPI / QR' },
                          { id: 'Online', label: '🌐 NetBanking' },
                          { id: 'Card', label: '💳 Card Gateway' }
                        ].map(mode => (
                          <button
                            key={mode.id}
                            type="button"
                            onClick={() => setPaymentMode(mode.id as any)}
                            className={`p-2 border text-[11px] font-bold rounded-lg transition-colors ${
                              paymentMode === mode.id 
                                ? 'bg-blue-600 border-blue-600 text-white' 
                                : 'bg-transparent border-slate-200 text-slate-600 hover:bg-slate-50'
                            }`}
                          >
                            {mode.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-md shadow-blue-500/15 transition-all"
                    >
                      Process Payment of ₹{Number(payAmount) > 0 ? Number(payAmount).toLocaleString('en-IN') : '0'}
                    </button>
                  </form>
                ) : (
                  <div className="bg-emerald-50 text-emerald-700 border border-emerald-100 p-4 rounded-xl text-center text-xs font-bold space-y-1">
                    <CheckCircle size={22} className="mx-auto text-emerald-500" />
                    <div>TUITION CLEARANCE COMPLETED</div>
                    <p className="font-medium text-[10px] text-emerald-600">No pending outstanding balance left on this account.</p>
                  </div>
                )}

                {paymentSuccess && (
                  <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-[11px] text-emerald-700 space-y-1 animate-in fade-in duration-200">
                    <div className="font-bold flex items-center gap-1">
                      <CheckCircle size={14} /> Payment Captured Successfully!
                    </div>
                    <p className="font-mono">Receipt No: {lastReceipt} was appended to your billing log.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Personal Fee Transactions */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold mb-4">My Payment Log</h3>
              <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                {studentTx.length > 0 ? (
                  studentTx.map(tx => (
                    <div key={tx.id} className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex justify-between items-center text-xs">
                      <div className="space-y-1">
                        <div className="font-bold text-slate-800">₹{tx.amount.toLocaleString('en-IN')}</div>
                        <p className="text-[10px] text-slate-400 font-mono">{tx.receiptNo} • {tx.date}</p>
                      </div>
                      <span className="bg-emerald-50 border border-emerald-100 text-emerald-700 font-mono text-[9px] px-1.5 py-0.5 rounded font-bold">
                        {tx.paymentMode}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-slate-400 text-xs py-6">No payment receipts logged yet.</div>
                )}
              </div>
            </div>
          </div>

          {/* School Store Portal */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
              <div className="flex justify-between items-center mb-1">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 font-sans">PJRS School Utilities & Essentials Store</h3>
                  <p className="text-[11px] text-slate-500">Instant gateway to purchase uniform elements, books, ties, and bags.</p>
                </div>
                <ShoppingBag size={20} className="text-slate-400" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                {STORE_ITEMS.map((item) => {
                  const ItemIcon = item.icon;
                  return (
                    <div key={item.id} className="p-4 border border-slate-100 rounded-2xl bg-slate-50/50 hover:bg-slate-50 transition-all flex flex-col justify-between space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between items-start">
                          <span className="text-[9px] font-mono uppercase font-bold tracking-wider text-slate-400">
                            {item.category}
                          </span>
                          <span className="text-xs font-mono font-black text-slate-900 bg-white border border-slate-100 px-2 py-0.5 rounded-md shadow-2xs">
                            ₹{item.price}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-800 leading-snug">{item.name}</h4>
                      </div>

                      <button
                        onClick={() => handleBuyStoreItem(item.name, item.price)}
                        className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 px-3 rounded-lg text-[10px] transition-colors flex items-center justify-center gap-1.5"
                      >
                        ⚡ Order & Pay Now
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl text-xs text-slate-600 space-y-1 mt-6 leading-relaxed">
                <div className="font-bold flex items-center gap-1 text-amber-800">
                  <AlertCircle size={14} /> Dispatch Instructions:
                </div>
                <p className="text-[11px] text-amber-700">
                  All store purchases generate instant digital transaction vouchers in the ledger. Items will be dispatched within 24 hours of successful purchase directly to the students classroom teacher.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STUDENT ASSIGNMENTS */}
      {activeStudentTab === 'assignments' && (
        <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-sans">Active Homework & Homework Briefs</h3>
              <p className="text-[11px] text-slate-500">Upload assignment responses in PDF/JPG or Doc formats directly.</p>
            </div>
            <span className="text-xs font-mono text-slate-400 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded">
              Subject Lock: CLASS {currentStudent.class.toUpperCase()}
            </span>
          </div>

          <div className="space-y-4">
            {STATIC_ASSIGNMENTS.map((asg) => {
              const subKey = `${currentStudent.id}_${asg.id}`;
              const subInfo = submissions[subKey];
              return (
                <div key={asg.id} className="p-5 border border-slate-100 rounded-2xl bg-slate-50/50 hover:bg-slate-50 transition-all space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100/60 pb-3">
                    <div>
                      <span className="text-[9px] font-mono uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-50 text-blue-600 border border-blue-100">
                        {asg.subject}
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 mt-2">{asg.title}</h4>
                    </div>
                    <div className="font-mono text-[10px] text-slate-500 flex flex-col items-end">
                      <span>Max Score: <strong>{asg.maxMarks} Marks</strong></span>
                      <span className="text-rose-500 font-bold flex items-center gap-1 mt-1">
                        <Clock size={11} /> Deadline: {asg.dueDate}
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed">{asg.description}</p>

                  <div className="pt-3 border-t border-slate-100/60 flex flex-col sm:flex-row justify-between sm:items-center gap-3 text-xs">
                    {subInfo ? (
                      <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-100 p-2 rounded-xl">
                        <CheckCircle size={14} className="text-emerald-500" />
                        <div>
                          <div className="font-bold text-[10px]">Submitted: {subInfo.fileName}</div>
                          <p className="text-[9px] text-emerald-600 font-mono">Date Logged: {subInfo.date}</p>
                        </div>
                      </div>
                    ) : (
                      <span className="text-amber-600 bg-amber-50 border border-amber-100 px-2.5 py-1 rounded font-mono font-bold text-[10px] uppercase flex items-center gap-1 self-start sm:self-auto">
                        <AlertCircle size={12} /> Pending Submission
                      </span>
                    )}

                    <div className="flex items-center gap-3">
                      <label className="cursor-pointer bg-slate-900 hover:bg-slate-800 text-white font-bold py-1.5 px-3 rounded-lg text-[10px] transition-colors flex items-center gap-1">
                        <UploadCloud size={12} />
                        <span>{subInfo ? 'Re-Upload File' : 'Submit Homework'}</span>
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx,.jpg,.png"
                          onChange={(e) => handleMockUpload(asg.id, e)}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* STUDENT DIRECT TEACHER CHAT */}
      {activeStudentTab === 'chat' && (
        <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[500px]">
          {/* Teachers Sidebar */}
          <div className="md:col-span-4 border-r border-slate-100 bg-slate-50/50 p-4 space-y-4">
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">Faculty Help Desk</h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Select a class teacher to ask queries.</p>
            </div>

            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {staffList.filter(s => s.role === 'Teacher').map(teacher => {
                const isSelected = selectedTeacherId === teacher.id;
                return (
                  <button
                    key={teacher.id}
                    onClick={() => setSelectedTeacherId(teacher.id)}
                    className={`w-full text-left p-3 rounded-xl border text-xs flex items-center gap-3 transition-all ${
                      isSelected 
                        ? 'bg-white border-blue-500/30 text-blue-900 shadow-xs' 
                        : 'bg-transparent border-transparent text-slate-600 hover:bg-slate-200/50'
                    }`}
                  >
                    <div className="h-9 w-9 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold font-mono">
                      {teacher.name.split(' ').slice(-1)[0][0] || 'T'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold truncate">{teacher.name}</div>
                      <p className="text-[10px] text-slate-400 font-mono truncate">{teacher.subjectSpecialty || 'Instructor'}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Chat Window */}
          <div className="md:col-span-8 flex flex-col justify-between min-h-[400px]">
            {/* Active Teacher Header */}
            {selectedTeacherId ? (
              (() => {
                const teacherObj = staffList.find(st => st.id === selectedTeacherId);
                return (
                  <>
                    <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold font-mono text-xs">
                          {teacherObj?.name.split(' ').slice(-1)[0][0]}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900">{teacherObj?.name}</h4>
                          <span className="text-[9px] bg-blue-100 text-blue-800 font-mono px-1.5 py-0.5 rounded font-bold uppercase block w-max mt-0.5">
                            {teacherObj?.subjectSpecialty || 'Teacher'} Specialist
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-500 font-mono font-bold flex items-center gap-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> ONLINE
                      </span>
                    </div>

                    {/* Messages Scroll Area */}
                    <div className="flex-1 p-6 space-y-4 max-h-[320px] overflow-y-auto bg-slate-50/20">
                      {activeChatHistory.length > 0 ? (
                        activeChatHistory.map(msg => {
                          const isStudent = msg.sender === 'student';
                          return (
                            <div key={msg.id} className={`flex ${isStudent ? 'justify-end' : 'justify-start'}`}>
                              <div className={`max-w-md rounded-2xl p-3.5 text-xs shadow-3xs ${
                                isStudent 
                                  ? 'bg-blue-600 text-white rounded-tr-none' 
                                  : 'bg-white border border-slate-100 text-slate-800 rounded-tl-none'
                              }`}>
                                <p className="leading-relaxed">{msg.text}</p>
                                <span className={`text-[9px] font-mono mt-1 block text-right ${
                                  isStudent ? 'text-blue-200' : 'text-slate-400'
                                }`}>
                                  {msg.timestamp}
                                </span>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs py-12 gap-2">
                          <MessageSquare size={32} className="text-slate-300" />
                          <span>No conversation history yet. Send a query below to start!</span>
                        </div>
                      )}
                    </div>

                    {/* Send Message Form */}
                    <form onSubmit={handleSendChatMessage} className="p-4 border-t border-slate-100 flex gap-2">
                      <input
                        type="text"
                        value={typedMessage}
                        onChange={(e) => setTypedMessage(e.target.value)}
                        placeholder={`Type message to ${teacherObj?.name || 'teacher'}...`}
                        className="flex-1 bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                      <button
                        type="submit"
                        className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl transition-colors shrink-0"
                      >
                        <Send size={16} />
                      </button>
                    </form>
                  </>
                );
              })()
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400 text-xs gap-2">
                <User size={32} className="text-slate-300 animate-pulse" />
                <span>Select a teacher from the help desk menu.</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
