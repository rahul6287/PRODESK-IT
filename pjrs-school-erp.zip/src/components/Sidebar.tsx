import React from 'react';
import { 
  School, 
  Users, 
  DollarSign, 
  BookOpen, 
  Bell, 
  Settings, 
  Shield, 
  MapPin,
  ChevronRight,
  Sparkles,
  LogOut,
  UserCheck
} from 'lucide-react';
import { Branch, UserRole, BranchId } from '../types';

interface SidebarProps {
  branches: Branch[];
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  selectedBranchId: BranchId;
  setSelectedBranchId: (id: BranchId) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: any;
  onLogout: () => void;
}

export default function Sidebar({
  branches,
  currentRole,
  setCurrentRole,
  selectedBranchId,
  setSelectedBranchId,
  activeTab,
  setActiveTab,
  currentUser,
  onLogout
}: SidebarProps) {
  const getTabsByRole = () => {
    if (currentRole === 'student') {
      return [
        { id: 'student_dashboard', label: 'Student Hub', icon: School },
        { id: 'student_grades', label: 'My Mark Sheet', icon: BookOpen },
        { id: 'student_fees', label: 'Fees & Store', icon: DollarSign },
        { id: 'student_assignments', label: 'Homework Upload', icon: BookOpen },
        { id: 'student_chat', label: 'Talk to Teachers', icon: Bell },
      ];
    }
    if (currentRole === 'teacher') {
      return [
        { id: 'teacher_classroom', label: 'My Classroom', icon: School },
        { id: 'teacher_gradebook', label: 'Gradebook Portal', icon: BookOpen },
        { id: 'teacher_assignments', label: 'Assignment Planner', icon: BookOpen },
        { id: 'teacher_chat', label: 'Student Chat Room', icon: Bell },
      ];
    }
    // Super admin & Branch admin
    const isHQ = currentRole === 'super_admin';
    return [
      { id: 'dashboard', label: isHQ ? 'HQ Dashboard' : 'Branch Dashboard', icon: School },
      { id: 'students', label: isHQ ? 'HQ Student Explorer' : 'Branch Students', icon: Users },
      { id: 'staff', label: isHQ ? 'Group Staff Directory' : 'Branch Staff', icon: Users },
      { id: 'finance', label: isHQ ? 'Consolidated Finance' : 'Branch Finance', icon: DollarSign },
      { id: 'academics', label: isHQ ? 'Exams & Timetables' : 'Branch Academics', icon: BookOpen },
      { id: 'communication', label: 'Circulars & Notices', icon: Bell },
    ];
  };

  const tabs = getTabsByRole();

  const roles: { id: UserRole; label: string; desc: string }[] = [
    { id: 'super_admin', label: 'HQ Admin', desc: 'Consolidated across campuses' },
    { id: 'branch_admin', label: 'Branch Admin', desc: 'Restricted to single campus' },
    { id: 'teacher', label: 'Faculty View', desc: 'Log attendance & grades' },
    { id: 'student', label: 'Student / Parent', desc: 'View portal & pay fees' },
  ];

  return (
    <aside className="w-80 bg-slate-900 text-slate-100 flex flex-col border-r border-slate-800">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="bg-blue-600 p-2.5 rounded-xl shadow-lg shadow-blue-500/20 text-white">
          <School size={24} className="animate-pulse" />
        </div>
        <div>
          <h1 className="font-sans font-bold text-lg leading-tight tracking-tight text-white flex items-center gap-1.5">
            PJRS School ERP
          </h1>
          <p className="text-xs text-slate-400 font-mono">pjrs.org • v4.1</p>
        </div>
      </div>

      {/* Role / Profile Switcher or Active Session Card */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/40">
        {currentUser ? (
          <div className="space-y-3.5">
            <div className="flex items-center gap-2 px-1">
              <UserCheck size={14} className="text-emerald-400" />
              <span className="text-xs uppercase font-mono tracking-wider text-slate-400 font-bold">
                Active ERP Session
              </span>
            </div>
            
            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl space-y-1">
              <div className="text-xs font-bold text-slate-100 truncate">
                {currentUser.name}
              </div>
              <div className="text-[10px] font-mono text-slate-400 truncate">
                {currentUser.email || currentUser.rollNumber}
              </div>
              <div className="pt-2 flex items-center justify-between">
                <span className="text-[9px] font-mono font-extrabold uppercase tracking-widest text-blue-400 bg-blue-950 px-1.5 py-0.5 rounded border border-blue-900/50">
                  {currentRole === 'super_admin' 
                    ? 'HQ Admin' 
                    : currentRole === 'branch_admin' 
                      ? 'Branch Admin' 
                      : currentRole === 'teacher' 
                        ? 'Class Faculty' 
                        : 'Enrolled Student'}
                </span>
                {currentUser.class && (
                  <span className="text-[9px] font-mono font-bold text-slate-300">
                    {currentUser.class}-{currentUser.section}
                  </span>
                )}
              </div>
            </div>

            <button
              onClick={onLogout}
              className="w-full flex items-center justify-center gap-2 bg-red-950/50 hover:bg-red-900/30 text-red-200 border border-red-900/40 py-2 rounded-lg text-xs font-bold transition-all"
            >
              <LogOut size={13} />
              <span>Sign Out Gateway</span>
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-3 px-2">
              <Shield size={14} className="text-blue-400" />
              <span className="text-xs uppercase font-mono tracking-wider text-slate-400 font-semibold">
                Select Live View Role
              </span>
            </div>
            <div className="grid grid-cols-1 gap-2">
              {roles.map((r) => {
                const isSelected = currentRole === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => {
                      setCurrentRole(r.id);
                      // Auto-switch branch rules depending on role
                      if (r.id !== 'super_admin' && selectedBranchId === 'all') {
                        setSelectedBranchId('central');
                      }
                    }}
                    className={`w-full text-left p-2.5 rounded-lg transition-all duration-200 border text-xs flex flex-col gap-0.5 ${
                      isSelected
                        ? 'bg-blue-600/15 border-blue-500/40 text-blue-100 shadow-sm'
                        : 'bg-transparent border-transparent text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-semibold flex items-center justify-between">
                      <span>{r.label}</span>
                      {isSelected && <span className="h-1.5 w-1.5 rounded-full bg-blue-400 animate-ping" />}
                    </div>
                    <span className="text-[10px] text-slate-500">{r.desc}</span>
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* Branch Selector (HQ Super Admin can view 'All' or specific, others lock onto selected) */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/20">
        <div className="flex items-center gap-2 mb-2 px-2">
          <MapPin size={14} className="text-emerald-400" />
          <span className="text-xs uppercase font-mono tracking-wider text-slate-400 font-semibold">
            {currentRole === 'super_admin' ? 'Active Scope / Campus' : 'Assigned Campus'}
          </span>
        </div>

        {currentRole === 'super_admin' ? (
          <select
            value={selectedBranchId}
            onChange={(e) => setSelectedBranchId(e.target.value as BranchId)}
            className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
          >
            <option value="all">🌐 All 4 Branches (Consolidated)</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                📍 {b.name}
              </option>
            ))}
          </select>
        ) : (
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded-lg text-xs flex items-center justify-between text-slate-300">
            <span className="truncate">
              📍 {branches.find((b) => b.id === selectedBranchId)?.name || 'Central Campus'}
            </span>
            <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-900/50 font-mono">
              LOCKED
            </span>
          </div>
        )}
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
        <div className="px-2 pb-2 text-[10px] uppercase font-mono tracking-wider text-slate-500">
          Core ERP Modules
        </div>
        {tabs.map((tab) => {
          const IconComponent = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs transition-all duration-150 ${
                isActive
                  ? 'bg-slate-800 text-white font-medium border-l-2 border-blue-500'
                  : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <IconComponent size={16} className={isActive ? 'text-blue-400' : 'text-slate-500'} />
                <span>{tab.label}</span>
              </div>
              <ChevronRight size={14} className={`opacity-0 transition-opacity duration-150 ${isActive ? 'opacity-100 text-blue-400' : ''}`} />
            </button>
          );
        })}
      </nav>

      {/* Footer Details */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/50 flex flex-col gap-2">
        <div className="flex items-center gap-2 justify-between">
          <span className="text-[10px] font-mono text-slate-500">Live Status:</span>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-mono text-emerald-400 font-semibold uppercase">pjrs.org Live</span>
          </div>
        </div>
        <div className="text-[10px] text-slate-500 text-center leading-relaxed font-mono">
          © 2026 PJRS Group of Schools
        </div>
      </div>
    </aside>
  );
}
