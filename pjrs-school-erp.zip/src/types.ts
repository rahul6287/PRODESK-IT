export type BranchId = 'all' | 'central' | 'east' | 'south' | 'west';

export interface Branch {
  id: string;
  name: string;
  code: string;
  address: string;
  principal: string;
  phone: string;
  email: string;
  establishedYear: number;
  capacity: number;
  color: string; // for UI charts/branding
}

export type UserRole = 'super_admin' | 'branch_admin' | 'teacher' | 'student';

export interface Student {
  id: string;
  rollNumber: string;
  name: string;
  class: string; // e.g. "Class 10"
  section: string; // e.g. "A"
  branchId: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  parentName: string;
  parentPhone: string;
  parentEmail: string;
  email?: string;
  password?: string;
  status: 'Active' | 'Suspended' | 'Alumni';
  attendanceRate: number; // e.g. 85.5%
  admissionDate: string;
  feesTotal: number;
  feesPaid: number;
  feesDue: number;
  grades: {
    Mathematics?: number;
    Science?: number;
    English?: number;
    History?: number;
    Hindi?: number;
  };
}

export interface Staff {
  id: string;
  empId: string;
  name: string;
  role: 'Teacher' | 'Principal' | 'Admin' | 'Finance' | 'Support';
  branchId: string;
  email: string;
  password?: string;
  phone: string;
  salary: number;
  salaryStatus: 'Paid' | 'Pending';
  qualification: string;
  joiningDate: string;
  subjectSpecialty?: string;
  assignedClass?: string; // e.g., "Class 10-A"
}

export interface FeeTransaction {
  id: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  branchId: string;
  amount: number;
  date: string;
  paymentMode: 'Cash' | 'Online' | 'Cheque' | 'UPI';
  status: 'Paid' | 'Failed' | 'Pending';
  receiptNo: string;
}

export interface TimetableItem {
  id: string;
  className: string; // e.g., "Class 10"
  section: string; // e.g., "A"
  branchId: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  subject: string;
  teacherName: string;
  startTime: string;
  endTime: string;
  roomNo: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  branchId: string; // 'all' or branch id
  date: string;
  sender: string;
  target: 'All' | 'Parents' | 'Teachers' | 'Students';
  priority: 'High' | 'Medium' | 'Low';
}
